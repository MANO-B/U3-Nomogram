library(shiny)
library(shinyWidgets)
library(shinythemes)
library(shinydashboard)
library(scales)
library(ggplot2)
library(tidyr)
library(readr)
library(dplyr)
library(stringr)
library(ComplexHeatmap)
library(RColorBrewer)
library(gt)
library(gtsummary)
library(flextable)
library(gridExtra)
library(DT)
library(ggsci)
library(ggrepel)
library(patchwork)
library(markdown)
library(pROC)
library(rms)
library(tidymodels)
library(withr)
library(ranger)
library(bonsai)
library(probably)
library(discrim)
library(blorr)
library(dcurves)

tidymodels_prefer()
options(pillar.advice = FALSE, pillar.min_title_chars = Inf)

nietzsche = read.csv(header = TRUE,
                     file("source/nietzsche.csv",
                          encoding='UTF-8-BOM'))$text
SF_Genes = read.csv("source/SF_Genes.tsv",sep = "\t")$Gene
conversion_rate_table_data = read.csv("source/conversion_rate_table_data.tsv", sep="\t")
cancer_gene_list = read.csv(header = TRUE,sep = "\t",
                     file("source/cancerGeneList_oncoKB.txt",
                          encoding='UTF-8-BOM'))
histology_list = read.csv(header = FALSE,sep = "\t",
                            file("source/info.txt"))
histology_list = str_split(histology_list[,1], "_in_", simplify = T)[,2]
histology_name = str_split(histology_list, "_total_", simplify = T)[,1]
histology_number = str_split(histology_list, "_total_", simplify = T)[,2]
histology_number = str_split(histology_number, "_patients", simplify = T)[,1]
histology_number = as.integer(histology_number)
names(histology_number) = histology_name
histology_number["BRAIN"] = histology_number["BRAIN"] + histology_number["WHO_BRAIN"]
histology_number = histology_number[names(histology_number) != "WHO_BRAIN"]

# Specify the application port
options(shiny.host = "0.0.0.0")
options(shiny.port = 3838)

ht_opt$message = FALSE
options(shiny.maxRequestSize=16*1024^3)

Abs = function(x){
  x = as.numeric(x)
  x[is.na(x)]=1
  return(x)
}

fun_zero <- function(a, b){
  if(length(a) != length(b)){
    if(length(a) / length(b) == as.integer(length(a) / length(b))){
      b = rep(b,length(a) / length(b))
    }
  }
  return(ifelse(b == 0, 0, a / b))
}

gg_empty = function(){
  g = ggplot()
  g = g + geom_blank()
  g = g + ggtitle("Few data, not analyzed")
  plot(g)
}

odds.ratio <- function(a, b, c, d, correct=FALSE){
  cl <- function(x){
    or*exp(c(1,-1)*qnorm(x)*sqrt(1/a+1/b+1/c+1/d))
  }
  if (correct || a*b*c*d==0) {
    a <- a+0.5
    b <- b+0.5
    c <- c+0.5
    d <- d+0.5
  }
  or <- a*d/(b*c)
  conf <- rbind(cl90=cl(0.05), cl95=cl(0.025), cl99=cl(0.005), cl999=cl(0.0005))
  conf <- data.frame(conf)
  colnames(conf) <- paste(c("lower","upper"), " limit" , sep="")
  rownames(conf) <- paste(c(90, 95, 99, 99.9), "%CI" , sep="")
  list(or=or, conf=conf)
}

fun_oncoprint = function(Data_case_target,
                         oncogenic_genes,
                         gene,
                         gene_no,
                         oncoprint_option,
                         mid_age){
  withProgress(message = sample(nietzsche)[1], {
    col = c("SNP" = "red",
            "INS" = "blue",
            "DEL" = "green2",
            "DNP" = "orange1",
            "TNP" = "orange2",
            "ONP" = "orange3",
            "Other" = "orange4"
    )
    alter_fun = list(
      background = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                  gp = gpar(fill = "#EEEEEE", col = NA))
      },
      SNP_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                  gp = gpar(fill = col["SNP"], col = NA))
      },
      SNP_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h-unit(2, "pt"), 
                  gp = gpar(fill = col["SNP"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      },
      INS_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.8, 
                  gp = gpar(fill = col["INS"], col = NA))
      },
      INS_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.8, 
                  gp = gpar(fill = col["INS"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      },
      DEL_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.6, 
                  gp = gpar(fill = col["DEL"], col = NA))
      },
      DEL_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.6, 
                  gp = gpar(fill = col["DEL"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      },
      DNP_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["DNP"], col = NA))
      },
      DNP_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["DNP"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      },
      TNP_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["TNP"], col = NA))
      },
      TNP_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["TNP"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      },
      ONP_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["ONP"], col = NA))
      },
      ONP_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["ONP"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      },
      Other_S = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["Other"], col = NA))
      },
      Other_G = function(x, y, w, h) {
        grid.rect(x, y, w-unit(0, "pt"), h*0.4, 
                  gp = gpar(fill = col["Other"], col = NA))
        grid.rect(x, y, w-unit(0, "pt"), h*0.1, 
                  gp = gpar(fill = "#000000", col = NA))
      }
    )
    Data_oncoprint = Data_case_target %>%
      dplyr::select(ID,
                    pathology_top,
                    YoungOld,
                    Gene,
                    Panel,
                    age,
                    Variant_Type) %>%
      dplyr::arrange(ID) %>%
      dplyr::arrange(Panel) %>%
      dplyr::distinct(ID, .keep_all = T)
    gene = gene[gene %in% Data_oncoprint$Gene]
    if(length(gene) > 0){
      oncogenic_genes = unique(c(gene, oncogenic_genes))
    }
    gene_no = min(length(oncogenic_genes),
                  gene_no)
    mat_oncoprint = matrix("",
                           nrow = length(Data_oncoprint$ID),
                           ncol = gene_no)
    rownames(mat_oncoprint) = Data_oncoprint$ID
    colnames(mat_oncoprint) = oncogenic_genes[1:gene_no]
    Data_case_target = Data_case_target %>% dplyr::filter(Gene %in% oncogenic_genes[1:gene_no])
    incProgress(1 / 4)

    for(i in 1:length(Data_case_target$ID)){
        mat_oncoprint[Data_case_target[i,"ID"],
                      Data_case_target[i,"Gene"]] =
          paste(mat_oncoprint[Data_case_target[i,"ID"],
                              Data_case_target[i,"Gene"]],
                Data_case_target[i,"Variant_Type"],
                sep=";")
    }
    incProgress(1 / 4)
    
    rownames(mat_oncoprint) = Data_oncoprint$pathology_top
    mat_oncoprint = t(mat_oncoprint)
    column_title = paste("OncoPrint for frequent gene mutations")
    tmp = mat_oncoprint
    tmp[tmp != ""] = 1
    tmp[tmp == ""] = 0
    tmp = matrix(as.numeric(tmp), ncol = ncol(tmp))
    tmp2 = order(apply(tmp, FUN=sum, MARGIN=1))
    tmp = data.frame(tmp)
    colnames(tmp) = 1:ncol(tmp)
    sample_order = 1:ncol(tmp)
    colPal3 <- colorRampPalette(brewer.pal(11, "Spectral"))
    anno_diag = colnames(mat_oncoprint)
    anno_age = Data_oncoprint$YoungOld
    Data_oncoprint = Data_oncoprint %>%
      dplyr::mutate(anno_panel = case_when(
        Panel == "NOP_T" ~ "Somatic only",
        TRUE ~ "GPV (+)"))
    anno_panel = Data_oncoprint$anno_panel
    diag_list = names(sort(table(anno_diag),decreasing = TRUE))
    diag_list = factor(diag_list, levels = diag_list)
    diag_col = colPal3(length(diag_list))
    panel_list = unique(anno_panel)
    age_list = unique(anno_age)
    names(diag_col) = diag_list
    diag_list2 = sort(unique(anno_diag))
    diag_col2 = diag_col
    names(diag_col2) = diag_list2
    
    tmp3 = matrix(as.numeric(as.factor(mat_oncoprint)) - 1,
                  ncol = ncol(mat_oncoprint))
    tmp3 = data.frame(tmp3)
    colnames(tmp3) = 1:ncol(tmp3)
    for(l in rev(tmp2)){
      if(max(tmp3[l,]) != min(tmp3[l,])){
        sample_order_tmp = sample_order
        sample_order = NULL
        tmp4 = tmp3
        tmp5 = tmp
        tmp3 = tmp4[,0]
        tmp = tmp5[,0]
        for(m in sort(unique(unlist(as.vector(tmp4[l,]))),decreasing = F)){
          sample_order = c(sample_order, sample_order_tmp[tmp4[l,] == m])
          tmp3 = cbind(tmp3, tmp4[,tmp4[l,] == m])
          tmp = cbind(tmp, tmp5[,tmp4[l,] == m])
        }
      }
    }
    
    for(l in tmp2){
      if(!all(tmp[l,] == 1) & !all(tmp[l,] == 0)){
        sample_order = c(sample_order[tmp[l,] == 1], sample_order[tmp[l,] == 0])
        tmp = cbind(tmp[,tmp[l,] == 1], tmp[,tmp[l,] == 0])
      }
    }
    sample_order_simple = sample_order
    if(oncoprint_option == "Sort by pathology"){
      sample_order_final = NULL
      for(l in diag_list){
        sample_order_final = c(sample_order_final,
                               sample_order[sample_order %in% (1:length(sample_order))[(anno_diag == l)]])
      }
    } else if(oncoprint_option == "Sort by age"){
      sample_order_final_age = NULL
      for(l in age_list){
        sample_order_final_age = c(sample_order_final_age,
                               sample_order[sample_order %in% (1:length(sample_order))[(anno_age == l)]])
      }
    } else if(oncoprint_option == "Sort by somatic-germline"){
      sample_order_final_panel = NULL
      for(l in panel_list){
        sample_order_final_panel = c(sample_order_final_panel,
                                   sample_order[sample_order %in% (1:length(sample_order))[(anno_panel == l)]])
      }
    }
    incProgress(1 / 4)
    
    ha = HeatmapAnnotation(Diagnosis = anno_diag,
                           Age = anno_age,
                           `Somatic-germline` = anno_panel,
                           col = list(Diagnosis = diag_col2,
                                      Age = c("Older" = "green", "Younger" = "blue"),
                                      `Somatic-germline` = c("Somatic only" = "purple1", "GPV (+)" = "orange")),
                           annotation_height = unit(15, "mm"),
                           annotation_legend_param = list(Age = list(title = paste(mid_age, ">= Age, or older")),
                                                          `Somatic-germline` = list(title = "Somatic-germline"),
                                                          Diagnosis = list(title = "Diagnosis",at = diag_list)))
    if(oncoprint_option == "Sort by mutation frequency"){
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_simple, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    } else if(oncoprint_option == "Sort by age"){
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_final_age, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    } else if(oncoprint_option == "Sort by somatic-germline"){
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_final_panel, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    } else{
      ht = oncoPrint(mat_oncoprint, get_type = function(x) gsub(":.*$", "", strsplit(x, ";")[[1]]),
                     column_order = sample_order_final, row_order = rev(tmp2),
                     alter_fun = alter_fun, col = col,  pct_gp = gpar(fontsize = 10),
                     column_title = column_title,
                     remove_empty_columns = FALSE, remove_empty_rows = FALSE,
                     bottom_annotation = ha,
                     use_raster = FALSE,
                     #height = unit(200, "mm"),
                     alter_fun_is_vectorized = TRUE)
    }
    draw(ht)
    incProgress(1 / 4)
  })
}

# Define UI for application that draws a histogram
ui <- dashboardPage(skin = "black",
  dashboardHeader(tags$li(class = "dropdown",
                          tags$table(style="80%;align:center;border-collapse:seperate;border-spacing:20px;"),
                          tags$style(".main-header {max-height: 30px}"),
                          tags$style(".main-header .logo {height: 30px;}"),
                          tags$style(".sidebar-toggle {height: 30px; padding-top: 1px !important;}"),
                          tags$style(".navbar {min-height:30px !important}")),
                  title = HTML(
                    "<div style = 'background-color:FFFFFF; vertical-align:top'>
       <a href='https://github.com/MANO-B/MANomogram'><img src = 'source/MANO.png', align = 'left', height = '30px'></a> 
       </div><h6>MANomogram version 1.7.2</h6>")
  ),
  dashboardSidebar(
    tags$style(".sidebar {height: calc(100vh - 30px); overflow-y: scroll; scrollbar-width: none;.left-side}, .main-sidebar {padding-top: 30px}"),
    sidebarMenu(style = "white-space: normal;",
      h3("Settings"),
      menuItem("Input C-CAT files", tabName = "Input_files", icon = icon("dashboard")),
      menuItem("Setting", tabName = "Setting", icon = icon("dashboard")),
      menuItem("Analysis", tabName = "Analysis", icon = icon("th")),
      hr(),
      h3("Results"),
      menuItem("Case summary", icon = icon("th"),
               hr(),
               p("Tables"),
               menuSubItem("Summarized all", tabName = "Summarize", icon = icon("angle-right")),
               menuSubItem("Summarized by histology", tabName = "Summarize_histology", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Mutation summary", icon = icon("th"),
               hr(),
               p("Figures"),
               menuSubItem("VAF histograms", tabName = "VAF_histogram", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Oncoprint", icon = icon("th"),
               hr(),
               p("Figures"),
               menuSubItem("Oncoprint", tabName = "Oncoprint", icon = icon("angle-right")),
               menuSubItem("Lolliplot for the selected gene", tabName = "Lolliplot", icon = icon("angle-right")),
               hr(),
               p("Downloadable table"),
               menuSubItem("Table of clinical and mutation information per patient", tabName = "Table_summary", icon = icon("angle-right")),
               hr()
      ),
      menuItem("Variants and histology", icon = icon("th"),
               hr(),
               p("Figures"),
               menuSubItem("All variants", tabName = "Variation_histology_all", icon = icon("angle-right")),
               menuSubItem("Somatic variants", tabName = "Variation_histology_somatic", icon = icon("angle-right")),
               menuSubItem("Germline variants", tabName = "Variation_histology_germline", icon = icon("angle-right")),
               menuSubItem("Conversion rate", tabName = "Variation_histology_conversion_rate", icon = icon("angle-right")),
               menuSubItem("False negative rate", tabName = "Variation_histology_false_negative_rate", icon = icon("angle-right")),
               hr()
      ),
      menuItem("GPV estimation for all genes", icon = icon("th"),
               hr(),
               p("Figures"),
               menuSubItem("Basic data", tabName = "GPV_basic_data", icon = icon("angle-right")),
               menuSubItem("Nomogram", tabName = "GPV_Nomogram", icon = icon("angle-right")),
               menuSubItem("Odds ratio", tabName = "GPV_Odd_sratio", icon = icon("angle-right")),
               menuSubItem("Decision curve", tabName = "GPV_decision_curve", icon = icon("angle-right")),
               menuSubItem("ROC curve", tabName = "ROC_nomogram", icon = icon("angle-right")),
               menuSubItem("Kosugi's criteria", tabName = "GPV_Kosugi", icon = icon("angle-right")),
               menuSubItem("Machine learning", tabName = "GPV_Machinelearning", icon = icon("angle-right")),
               hr(),
               p("Table"),
               menuSubItem("Table for decision curve", tabName = "DCA_table", icon = icon("angle-right")),
               menuSubItem("Prediction result table", tabName = "Table_prediction", icon = icon("angle-right"))
      ),
      menuItem("GPV estimation for secondary-finding genes", icon = icon("th"),
               hr(),
               p("Figures"),
               menuSubItem("Basic data", tabName = "SF_GPV_basic_data", icon = icon("angle-right")),
               menuSubItem("Nomogram", tabName = "SF_GPV_Nomogram", icon = icon("angle-right")),
               menuSubItem("Odds ratio", tabName = "SF_GPV_Odd_sratio", icon = icon("angle-right")),
               menuSubItem("Decision curve", tabName = "SF_GPV_decision_curve", icon = icon("angle-right")),
               menuSubItem("ROC curve", tabName = "SF_ROC_nomogram", icon = icon("angle-right")),
               menuSubItem("Kosugi's criteria", tabName = "SF_GPV_Kosugi", icon = icon("angle-right")),
               menuSubItem("Machine learning", tabName = "SF_GPV_Machinelearning", icon = icon("angle-right")),
               hr(),
               p("Table"),
               menuSubItem("Table for decision curve", tabName = "SF_DCA_table", icon = icon("angle-right")),
               menuSubItem("Prediction result table", tabName = "SF_Table_prediction", icon = icon("angle-right"))
      ),
      # menuItem("Validation", icon = icon("th"),
      #          hr(),
      #          p("Figures"),
      #          menuSubItem("ROC curve", tabName = "ROC_validation", icon = icon("angle-right")),
      #          hr(),
      #          p("Table"),
      #          menuSubItem("Sensitivity-Specificity", tabName = "Validation_table", icon = icon("angle-right"))
      # ),
      hr(),
      h3("Prediction"),
      menuItem("Analyze your data", tabName = "Input_data", icon = icon("th")),
      hr(),
      h3("Instruction"),
      menuItem("About MANomogram", tabName = "Instruction", icon = icon("th")),
      hr()
    )
  ),
  ## Body content
  dashboardBody(style='overflow-x: scroll;overflow-y: scroll;',
                tags$head(tags$style(HTML('
      .main-header .sidebar-toggle:before {
        content: "\\e068";}'))),
    tabItems(
      # First tab content
      tabItem(tabName = "Input_files",
              fluidRow(
                column(4,
                       strong("Required: C-CAT CALICO pathogenic variant data tsv file"),
                       hr(),
                       fileInput(inputId = "clinical_files",
                                 label = "Choose case CSV Files",
                                 multiple = FALSE
                       ),
                       hr(),
                       br(),
                       br(),
                       downloadButton('download_test_clinical_data', 'Download sample data'),
                       br(),
                       br(),
                )
              ),
              hr(),
              h6("MANomogram; MGPT advocacy Nomogram."),
              a(href="https://github.com/MANO-B/MANomogram",h6("https://github.com/MANO-B/MANomogram"))
      ),
      tabItem(tabName = "Setting",
              actionButton("start_setting", "Start file loading/analysis settings"),
              br(),
              hr(),
              fluidRow(
                column(3,strong("Filter on histology"),
                       hr(),
                       htmlOutput("select_histology"),
                       htmlOutput("select_minimum_pts"),
                       br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),
                       br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),
                       hr()
                ),
                column(3,strong("Filters for clinical information"),
                       hr(),
                       htmlOutput("select_sex"),
                       htmlOutput("select_age"),
                       htmlOutput("select_mid_age")
                ),
                column(3,strong("Filters on genes"),
                       hr(),
                       htmlOutput("select_gene"),
                       htmlOutput("select_lolliplot_gene"),
                       htmlOutput("select_lolliplot_no"),
                       br(),
                       br()
                ),
                column(3,strong("Other Settings"),
                       hr(),
                       htmlOutput("select_gene_no"),
                       htmlOutput("select_oncoprint_option")
                ),
              ),
              br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),
              br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),br(),
              hr()
      ),
      tabItem(tabName = "Analysis",
              fluidRow(
                column(4,
                       strong("Standard Analysis"),
                       hr(),
                       actionButton("summary_base", "Case summary"),
                       br(),
                       br(),
                       actionButton("summary_mutation", "Mutation summary"),
                       br(),
                       br(),
                       actionButton("oncoprint", "Oncoprint"),
                       br(),
                       br(),
                       actionButton("mut_subtype", "Variants and histology"),
                       br(),
                       br(),
                       actionButton("PGPV_prediction", "PGPV prediction analysis for all genes"),
                       br(),
                       br(),
                       actionButton("SF_PGPV_prediction", "PGPV prediction analysis for secondary-findings genes"),
                       br(),
                       br()
                ),
             ),
             hr(),
             h5("Figures in results are downloadable as png files.")
      ),
      tabItem(tabName = "Summarize",
              gt_output("table_summary_1"),
                       hr(),
                       h6(paste("Table. Characteristics for patients with pathogenic mutations.",
                                "The present, retrospective cohort study was performed with clinicogenomic,",
                                "real-world data on the patients who were registered in the C-CAT database",
                                "from June 1, 2019 to February 16, 2024. The patients were registered by hospitals throughout Japan",
                                "and provided written informed consent to the secondary use of their clinicogenomic",
                                "data for research."))
      ),
      tabItem(tabName = "Summarize_histology",
              gt_output("table_summary_2"),
                       hr(),
                       h6("Table. Characteristics for patients with pathogenic mutations.")
      ),
      tabItem(tabName = "VAF_histogram",
              plotOutput('figure_VAF_histogram', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Variant frequency of somatic/germline variants.")
      ),
      tabItem(tabName = "Oncoprint",
              plotOutput('figure_oncoprint', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Recurrent oncogenic mutations in selected cases. The 30 genes with the highest frequency of oncogenic mutations are shown. Mutational landscapes were created using ComplexHeatmap package for R.")
      ),
      tabItem(tabName = "Lolliplot",
              plotOutput('figure_lolliplot2', 
                                  height = "500px",
                                  width = "1500px"),
                       hr(),
                       h6("Figure. Frequency of oncogenic mutations in the selected gene. The most frequent oncogenic mutations are shown with amino acid change."),
                       h6("Mutplot by Zhang W, PMID:31091262. If error occurs, correct 'source/UniPlot.txt'."),
                       h6("Protein structure source: Uniprot"),
                       HTML("<p>Github for Mutplot. <a href='https://github.com/VivianBailey/Mutplot'>Link for the website</a></p>")
      ),
      tabItem(tabName = "Table_summary",
              DT::dataTableOutput("table_patient")
      ),
      tabItem(tabName = "Variation_histology_all",
              plotOutput('figure_mut_all', 
                                  height = "1000px",
                                  width = "1000px"),
                       hr(),
                       h6("Figure. Recurrent oncogenic mutations across subtypes. The 30 genes with the highest frequency of oncogenic mutations were displayed.")
      ),
      tabItem(tabName = "Variation_histology_somatic",
              plotOutput('figure_mut_somatic', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Recurrent oncogenic mutations across subtypes. The 30 genes with the highest frequency of oncogenic mutations were displayed.")
      ),
      tabItem(tabName = "Variation_histology_germline",
              plotOutput('figure_mut_germline', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Recurrent oncogenic mutations across subtypes. The 30 genes with the highest frequency of oncogenic mutations were displayed.")
      ),
      tabItem(tabName = "Variation_histology_conversion_rate",
              plotOutput('figure_mut_conversion_rate', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Recurrent oncogenic mutations across subtypes. The 30 genes with the highest frequency of oncogenic mutations were displayed.")
      ),
      tabItem(tabName = "Variation_histology_false_negative_rate",
              plotOutput('figure_mut_false_negative', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Recurrent oncogenic mutations across subtypes. The 30 genes with the highest frequency of oncogenic mutations were displayed.")
      ),
      tabItem("GPV_basic_data",
              plotOutput('figure_GPV_basic_data', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Basic data of GPV prediction analysis.")
      ),
      tabItem("GPV_Nomogram",
              plotOutput('figure_nomogram', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Based on clinical information obtained prior to CGP testing, a nomogram was developed to predict the likelihood of actually receiving treatment based on the genetic mutations after CGP. The nomogram was created with the lrm function of the rms package for R with a setting of penalty=0.1. Cox-Snell R2 was calculated with blorr package for R. Possible sampling bias was corrected with 500-time bootstrap sampilng and then concordance index was estimated.")
      ),
      tabItem("GPV_Odd_sratio",
              gt_output('figure_Odds'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterion with stat package for R.")
      ),
      tabItem("GPV_decision_curve",
              plotOutput('figure_DCA', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Decision curve analysis was performed to verify the usefulness of the nomogram with dcurves package for R. Ten-fold cross-validation was performed to prevent overfitting. If the blue line is located above the other lines, then the nomogram-based decision to perform CGP testing may be worthwhile.")
      ),
      tabItem("ROC_nomogram",
              plotOutput('figure_DCA_ROC', 
                         height = "3000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate and Receiver Operatorating Characteristic curve of the nomogram using pre-CGP information by pROC package for R.")
      ),
      tabItem("GPV_Kosugi",
              plotOutput('figure_Kosugi', 
                         height = "2500px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate with Kosugi's criteria.")
      ),
      tabItem("GPV_Machinelearning",
              plotOutput('figure_Machine_learning', 
                         height = "2500px",
                         width = "1200px"),
              hr(),
              h6("Figure. Predicted treatment reach rate with Random forest and LightGBM models using pre-CGP information by tidymodels package for R. Generalized additive model was used for calibration. 10-fold cross validation was performed.")
      ),
      tabItem("DCA_table",
              gt_output('table_DCA')
      ),
      tabItem(tabName = "Table_prediction",
              DT::dataTableOutput("table_prediction")
      ),
      tabItem("SF_GPV_basic_data",
              plotOutput('SF_figure_GPV_basic_data', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Basic data of GPV prediction analysis.")
      ),
      tabItem("SF_GPV_Nomogram",
              plotOutput('SF_figure_nomogram', 
                         height = "2000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Based on clinical information obtained prior to CGP testing, a nomogram was developed to predict the likelihood of actually receiving treatment based on the genetic mutations after CGP. The nomogram was created with the lrm function of the rms package for R with a setting of penalty=0.1. Cox-Snell R2 was calculated with blorr package for R. Possible sampling bias was corrected with 500-time bootstrap sampilng and then concordance index was estimated.")
      ),
      tabItem("SF_GPV_Odd_sratio",
              gt_output('SF_figure_Odds'),
              hr(),
              h6("Table. Univariable and multiple variable regression analysis were performed with gtsummary package for R. Factors selected in the multivariable analysis were selected by variable decreasing method based on the Akaike information criterion with stat package for R.")
      ),
      tabItem("SF_GPV_decision_curve",
              plotOutput('SF_figure_DCA', 
                         height = "1000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Decision curve analysis was performed to verify the usefulness of the nomogram with dcurves package for R. Ten-fold cross-validation was performed to prevent overfitting. If the blue line is located above the other lines, then the nomogram-based decision to perform CGP testing may be worthwhile.")
      ),
      tabItem("SF_ROC_nomogram",
              plotOutput('SF_figure_DCA_ROC', 
                         height = "3000px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate and Receiver Operatorating Characteristic curve of the nomogram using pre-CGP information by pROC package for R.")
      ),
      tabItem("SF_GPV_Kosugi",
              plotOutput('SF_figure_Kosugi', 
                         height = "2500px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate with Kosugi's criteria.")
      ),
      tabItem("SF_GPV_Machinelearning",
              plotOutput('SF_figure_Machine_learning', 
                         height = "2500px",
                         width = "1000px"),
              hr(),
              h6("Figure. Predicted treatment reach rate with Random forest and LightGBM models using pre-CGP information by tidymodels package for R. Generalized additive model was used for calibration. 10-fold cross validation was performed.")
      ),
      tabItem("SF_DCA_table",
              gt_output('SF_table_DCA')
      ),
      tabItem(tabName = "SF_Table_prediction",
              DT::dataTableOutput("SF_table_prediction")
      ),
      tabItem(tabName = "Input_data",
              actionButton("predict_nomogram_setting", "Start prediction setting"),
              htmlOutput("predict_method"),
              br(),
              hr(),
              fluidRow(
                column(4,strong("Clinical information"),
                       hr(),
                       htmlOutput("input_age"),
                       htmlOutput("input_sex"),
                       htmlOutput("input_sampling_site"),
                       htmlOutput("input_smoking_history"),
                       htmlOutput("input_alcohol"),
                       htmlOutput("input_cancer_family_history"),
                       htmlOutput("input_organ"),
                       htmlOutput("input_double_cancer"),
                       htmlOutput("input_multiple_nodule"),
                       br(),
                       hr()
                ),
                column(4,strong("Mutation information"),
                       hr(),
                       htmlOutput("input_gene"),
                       htmlOutput("input_Mut_Pattern"),
                       htmlOutput("input_VAF"),
                       htmlOutput("input_tumor_content"),
                       p("Check allele/genotype frequency in healthy population."),
                       a(href="https://jmorp.megabank.tohoku.ac.jp/",p("https://jmorp.megabank.tohoku.ac.jp/")),
                       htmlOutput("input_MAF")#,
                       #htmlOutput("input_conversion_rate")
                ),
                column(4,
                       shinydashboard::box(
                         title = "Known conversion rate by Kosugi",
                         DT::DTOutput("conversion_rate_table"),
                         width = NULL
                       ),
                       p("Tumor type A: Breast Cancer, CNS Cancer, Glioma, Nerve Sheath Tumor, Peripheral Nervous System, PHEO-PGL"),
                       p("Tumor type B: Adrenocortical Carcinoma, Bone Cancer, Breast Cancer, CNS Cancer, Colorectal Cancer, Embryonal Tumor, Gestational Trophoblastic Disease, Glioma, Soft Tissue Sarcoma, Wilms Tumor")
                ),
              ),
              br(),
              hr(),
              br(),
              actionButton("start_prediction", "Start prediction"),
              hr(),
              verbatimTextOutput("prediction_nomogram"),
              br(),
              br(),
              hr()
      ),
      tabItem("Instruction",
              includeMarkdown("www/README.md")
      )
    )
  )
)

  
# Define server logic required to draw a histogram
server <- function(input, output, session) {
  Data_case_raw =  reactive({
    withProgress(message = "Data loading.", {
      Encode = guess_encoding(input$clinical_files[[1, 'datapath']])[[1]][[1]]
      if(Encode == "Shift_JIS"){
        Encode = "CP932"
      }
      clin_tmp <- read_tsv(col_names = TRUE,
                           file = input$clinical_files$datapath,
                           locale = locale(encoding=Encode),
                           num_threads=max(1, parallel::detectCores() - 1, na.rm = TRUE),
                           progress=FALSE,
                           name_repair=make.names,
                           col_types = cols(
                             Consequence = col_character(),
                             HGVSc = col_character(),
                             HGVSp = col_character(),
                             CLIN_SIG = col_character(),
                             LoF = col_character(),
                             gnomADg_AF_eas = col_double(),
                             ClinVar_CLNSIG = col_character(),
                             ToMMo_AF = col_double(),
                             ID = col_character(),
                             Chr = col_character(),
                             Pos = col_integer(),
                             Ref = col_character(),
                             Alt = col_character(),
                             Mismatch_Rate_Normal = col_double(),
                             Mismatch_Rate_Tumor = col_double(),
                             Depth_Alt_T = col_integer(),
                             Depth_Total_T = col_integer(),
                             Depth_Alt_N = col_integer(),
                             Depth_Total_N = col_integer(),
                             Gene = col_character(),
                             Panel = col_character(),
                             LoF_in_TSGs = col_logical(),
                             pathology_top = col_character(),
                             pathology_detail = col_character(),
                             age = col_integer(),
                             sex = col_character(),
                             sampling_site = col_character(),
                             tumor_content = col_integer(),
                             smoking_history = col_character(),
                             alcohol = col_character(),
                             double_cancer = col_character(),
                             multiple_nodule = col_character(),
                             cancer_family_history = col_character(),
                             sampling_to_test = col_integer(),
                             Recommend = col_character(),
                             Conversion_rate = col_integer(),
                             confirmation_test = col_character()
                           ),
                           show_col_types=FALSE)
      incProgress(1 / 4)
      clin_tmp = as.data.frame(clin_tmp)
      clin_tmp = clin_tmp %>% dplyr::mutate(
        pathology_top = case_when(
          pathology_top == "WHO_BRAIN" ~ "BRAIN",
          TRUE ~ pathology_top
        ))
      clin_tmp = clin_tmp %>% dplyr::mutate(
        pathology_detail = case_when(
          pathology_detail == "WHO_MBL_SHH-a_TP53-m" ~ "MBL",
          TRUE ~ pathology_detail
        ))
      clin_tmp = clin_tmp %>% dplyr::filter(
        !HGVSp %in% c("ENSP00000332353.6:p.Ser827Gly",
                               "ENSP00000347942.3:p.Arg114His",
                               "ENSP00000234420.5:p.Lys1358AspfsTer2;"))
      clin_tmp = clin_tmp %>% dplyr::filter(
        !HGVSc %in% c("ENST00000234420.11:c.4001+12_4001+15del;"))
      clin_tmp_na = clin_tmp %>% dplyr::filter(is.na(HGVSp))
      clin_tmp_na$Gene = apply(ifelse(
        matrix(str_split(clin_tmp_na$HGVSc, ";", simplify = T) != "", nrow=length(clin_tmp_na$Gene)),
        str_split(clin_tmp_na$Gene, ";", simplify = T), ""),
        1, str_flatten)
      clin_tmp_an = clin_tmp %>% dplyr::filter(!is.na(HGVSp))
      clin_tmp_an$Gene = apply(ifelse(
        matrix(str_split(clin_tmp_an$HGVSp, ";", simplify = T) != "", nrow=length(clin_tmp_an$Gene)),
               str_split(clin_tmp_an$Gene, ";", simplify = T), ""),
        1, str_flatten)
      clin_tmp = rbind(clin_tmp_na, clin_tmp_an)
      clin_tmp$HGVSp = str_split(clin_tmp$HGVSp, "p\\.",simplify = T)[,2]
      clin_tmp$HGVSp = str_replace_all(clin_tmp$HGVSp, ";","")
      clin_tmp$HGVSp = str_replace_all(clin_tmp$HGVSp, "fsTer","_fsTer")
      clin_tmp$HGVSp = str_split(clin_tmp$HGVSp, "fsTer.",simplify = T)[,1]
      clin_tmp$HGVSp = str_replace_all(clin_tmp$HGVSp, "_","fs")
      clin_tmp$pathology_detail[is.na(clin_tmp$pathology_detail)] = clin_tmp$pathology_top[is.na(clin_tmp$pathology_detail)]
      clin_tmp = clin_tmp %>% dplyr::mutate(
        Variant_Type = case_when(
          nchar(Ref) == 1 &
            nchar(Alt) == 1 &
            Panel == "NOP_T" ~ "SNP_S",
          nchar(Ref) == 1 &
            nchar(Alt) == 1 &
            Panel == "NOP_N" ~ "SNP_G",
          nchar(Ref) == 2 &
            nchar(Alt) == 2 &
            Panel == "NOP_T" ~ "DNP_S",
          nchar(Ref) == 2 &
            nchar(Alt) == 2 &
            Panel == "NOP_N" ~ "DNP_G",
          nchar(Ref) == 3 &
            nchar(Alt) == 3 &
            Panel == "NOP_T" ~ "TNP_S",
          nchar(Ref) == 3 &
            nchar(Alt) == 3 &
            Panel == "NOP_N" ~ "TNP_G",
          nchar(Ref) > 3 &
            nchar(Alt) > 3 &
            nchar(Ref) == nchar(Alt) &
            Panel == "NOP_T" ~ "ONP_S",
          nchar(Ref) > 3 &
            nchar(Alt) > 3 &
            nchar(Ref) == nchar(Alt) &
            Panel == "NOP_N" ~ "ONP_G",
          nchar(Ref) == 1 &
            nchar(Alt) > 1 &
            Panel == "NOP_T" ~ "INS_S",
          nchar(Ref) == 1 &
            nchar(Alt) > 1 &
            Panel == "NOP_N" ~ "INS_G",
          nchar(Ref) > 1 &
            nchar(Alt) == 1 &
            Panel == "NOP_T" ~ "DEL_S",
          nchar(Ref) > 1 &
            nchar(Alt) == 1 &
            Panel == "NOP_N" ~ "DEL_G",
          str_detect(Alt,"\\*") &
            Panel == "NOP_T" ~ "DEL_S",
          str_detect(Alt,"\\*") &
            Panel == "NOP_N" ~ "DEL_G",
          TRUE ~ "Other"
        )
      )
      clin_tmp$Conversion_rate = as.character(clin_tmp$Conversion_rate)
      Conversion_rate_rename = clin_tmp$Conversion_rate
      Conversion_rate_rename[Conversion_rate_rename == "1"] = "High"
      Conversion_rate_rename[Conversion_rate_rename == "2"] = "Middle"
      Conversion_rate_rename[Conversion_rate_rename == "3"] = "Low"
      Conversion_rate_rename[Conversion_rate_rename %in% c("4","5")] = "Unknown"
      clin_tmp$Conversion_rate = Conversion_rate_rename
      clin_tmp$tumor_content = as.integer(clin_tmp$tumor_content)
      clin_tmp$smoking_history[is.na(clin_tmp$smoking_history)]="Unknown"
      clin_tmp$alcohol[is.na(clin_tmp$alcohol)]="Unknown"
      clin_tmp$double_cancer[is.na(clin_tmp$double_cancer)]="Unknown"
      clin_tmp$multiple_nodule[is.na(clin_tmp$multiple_nodule)]="Unknown"
      clin_tmp$cancer_family_history[is.na(clin_tmp$cancer_family_history)]="Unknown"
      clin_tmp$confirmation_test[is.na(clin_tmp$confirmation_test)]="No_recommendation"
      clin_tmp$gnomADg_AF_eas[is.na(clin_tmp$gnomADg_AF_eas)]=0
      clin_tmp$ToMMo_AF[is.na(clin_tmp$ToMMo_AF)]=0
      incProgress(1 / 4)
    })
    return(clin_tmp)
  })

  Data_case =  reactive({
    clin_tmp = Data_case_raw()
    if(!is.null(input$minimum_pts)){
      Cancername = table((clin_tmp %>% dplyr::distinct(ID, pathology_detail))$pathology_detail)
      Cancername = names(Cancername[Cancername >= input$minimum_pts])
      clin_tmp = clin_tmp %>% dplyr::mutate(
        pathology_detail = case_when(
          pathology_detail %in% Cancername ~ pathology_detail,
          TRUE ~ pathology_top
      ))
    }
    if(!is.null(input$histology)){
      clin_tmp = clin_tmp %>%
      dplyr::filter(
        pathology_top %in% input$histology
      )
    }
    if(!is.null(input$sex)){
      clin_tmp = clin_tmp %>%
        dplyr::filter(
          sex %in% input$sex
        )
    }
    if(!is.null(input$age)){
      if(any(input$age != c(min(Data_case_raw()$age, na.rm = TRUE),
                            max(Data_case_raw()$age, na.rm = TRUE)))){
        clin_tmp$age = tidyr::replace_na(clin_tmp$age, -1) 
        clin_tmp = clin_tmp %>% dplyr::filter(
          age >= input$age[1] &
            age <= input$age[2]
        )
      }
    }
    if(!is.null(input$mid_age)){
      clin_tmp = clin_tmp %>% dplyr::mutate(YoungOld = case_when(
        age <= input$mid_age ~ "Younger",
        TRUE ~ "Older"))
    }
    clin_tmp = clin_tmp %>% dplyr::distinct() %>% dplyr::arrange(ID)
    clin_tmp = clin_tmp %>% dplyr::mutate(
      Oncogene_TSG = case_when(
        Gene %in% cancer_gene_list[cancer_gene_list$Oncogene == "Yes" & cancer_gene_list$TSG == "Yes",]$Gene ~ "Both",
        Gene %in% cancer_gene_list[cancer_gene_list$Oncogene == "Yes",]$Gene ~ "Oncogene",
        Gene %in% cancer_gene_list[cancer_gene_list$TSG == "Yes",]$Gene ~ "TSG",
        TRUE ~ "Other"
      )
    )
    cancer_gene_list
    return(clin_tmp)
  })

  observeEvent(input$start_setting, {
    withProgress(message = sample(nietzsche)[1], {
      output$select_histology = renderUI({ 
        pickerInput("histology", "Filter by histology",
                    choices = sort(unique(Data_case_raw()$pathology_top)), 
                    options = list(`actions-box` = TRUE),
                    selected = sort(unique(Data_case_raw()$pathology_top)), multiple = TRUE)
      })
      output$select_sex = renderUI({ 
        pickerInput("sex", "Filter by sex",
                    choices = sort(unique(Data_case_raw()$sex)), 
                    selected = sort(unique(Data_case_raw()$sex)), multiple = TRUE)
      })
      output$select_minimum_pts = renderUI({ 
        numericInput("minimum_pts", "Minimum patients for each histology",
                     value = 1,
                     min = 1,
                     max = length((Data_case_raw() %>% dplyr::distinct(ID))$ID),
                     step = 1)
      })
      incProgress(1 / 8)
      output$select_age = renderUI({ 
        sliderInput(inputId = "age", label = "Age for analysis",
                    value = c(
                      min(Data_case_raw()$age, na.rm = TRUE),
                      max(Data_case_raw()$age, na.rm = TRUE)),
                    min = min(Data_case_raw()$age, na.rm = TRUE),
                    max = max(Data_case_raw()$age, na.rm = TRUE),
                    step = 1)
      })
      output$select_mid_age = renderUI({
        tmp = Data_case_raw() %>% dplyr::distinct(ID, age)
        sliderInput(inputId = "mid_age", label = "Threshold age for oncoprint",
                    value = 29,
                    min = min(tmp$age, na.rm = TRUE),
                    max = max(tmp$age, na.rm = TRUE),
                    step = 1)
      })
      incProgress(1 / 8)
      output$select_gene = renderUI({ 
        pickerInput("gene", "Genes of interest (if any)",
                    choices = sort(unique(Data_case_raw()$Gene)),
                    options = list(`actions-box` = TRUE),
                    selected = SF_Genes,
                    multiple = TRUE)
      })
      output$select_gene_no = renderUI({ 
        numericInput(inputId = "gene_no", label = "Gene number for oncoprint",
                     value = min(40, length(sort(unique(Data_case_raw()$Gene)))),
                     min = max(1, length(input$gene)),
                     max = length(sort(unique(Data_case_raw()$Gene))),
                     step = 1)
      })
      output$select_lolliplot_gene = renderUI({ 
        pickerInput("lolliplot_gene", "Genes for lolliplot (if any)",
                    choices = c("", sort(unique(Data_case_raw()$Gene))), multiple = FALSE)
      })
      output$select_lolliplot_no = renderUI({
        tmp = Data_case_raw() %>% dplyr::distinct(ID, age)
        sliderInput(inputId = "lolliplot_no", label = "Threshold mutation count for lolliplot",
                    value = 10,
                    min = 1,
                    max = 100,
                    step = 1)
      })
      output$select_oncoprint_option = renderUI({ 
        radioButtons(
          "oncoprint_option", "Oncoprint setting",
          choices = c("Sort by mutation frequency", "Sort by pathology", "Sort by age", "Sort by somatic-germline"),
          selected = "Sort by mutation frequency")
      })
      incProgress(1 / 8)
    })
  })
  output$download_test_clinical_data = downloadHandler(
    filename = "sample_clinical.csv",
    content = function(file) {
      csv_file = read.csv(header = TRUE, file("source/sample_clinical.csv",
                                              encoding='UTF-8-BOM'))
      write_excel_csv(csv_file, file)
    }
  )

  observeEvent(input$summary_base, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      Data_summary = Data_case_target %>%
        dplyr::distinct(ID,.keep_all=TRUE) %>%
        dplyr::select(
          age,
          sex,
          pathology_top,
          pathology_detail,
          sampling_site,
          tumor_content,
          smoking_history,
          alcohol,
          double_cancer,
          multiple_nodule,
          cancer_family_history,
          sampling_to_test)
      incProgress(1 / 8)
  
      colnames_tmp = colnames(Data_summary)
      colnames_tmp[colnames_tmp == "age"] = "Age"
      colnames_tmp[colnames_tmp == "sex"] = "Sex"
      colnames_tmp[colnames_tmp == "pathology_top"] = "Organ"
      colnames_tmp[colnames_tmp == "pathology_detail"] = "Tumor subtype"
      colnames_tmp[colnames_tmp == "sampling_site"] = "Sampling site"
      colnames_tmp[colnames_tmp == "tumor_content"] = "Tumor content"
      colnames_tmp[colnames_tmp == "smoking_history"] = "Smoking history"
      colnames_tmp[colnames_tmp == "alcohol"] = "Alcohol history"
      colnames_tmp[colnames_tmp == "double_cancer"] = "Double cancer"
      colnames_tmp[colnames_tmp == "multiple_nodule"] = "Tumor with multiple nodules"
      colnames_tmp[colnames_tmp == "cancer_family_history"] = "Cancer falimy history"
      colnames_tmp[colnames_tmp == "sampling_to_test"] = "Time from sampling to test (days)"
      
      colnames(Data_summary) = colnames_tmp

      output$table_summary_1 <- render_gt({
        Data_summary %>% dplyr::select(
          -`Tumor subtype`) %>%
          tbl_summary(
            by = NULL,
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
                          type = list(all_continuous() ~ "continuous2",
                                      all_dichotomous() ~ "categorical"),
                          digits = all_continuous() ~ 2,
                          missing = "ifany") %>%
          modify_caption("**Patient Characteristics** (N = {N})") %>%
          add_n() %>%
          bold_labels() %>% as_gt()
      })
      incProgress(1 / 8)
      output$table_summary_2 <- render_gt({
        Data_summary %>% dplyr::select(
          -`Tumor subtype`) %>%
          tbl_summary(
            by = "Organ",
            statistic = list(all_continuous() ~ c("{N_nonmiss}",
                                                  "{mean} ({sd})",
                                                  "{median} ({p25}, {p75})", 
                                                  "{min}, {max}"),
                             all_categorical() ~ "{n} / {N} ({p}%)"),
            type = list(all_continuous() ~ "continuous2",
                        all_dichotomous() ~ "categorical"),
            digits = all_continuous() ~ 2,
            missing = "ifany") %>%
          modify_caption("**Patient Characteristics, by diagnosis** (N = {N})") %>%
          add_n() %>%
          bold_labels() %>% as_gt()
      })
      incProgress(1 / 8)
    })
  })

  observeEvent(input$summary_mutation, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      incProgress(1 / 8)
      Data_figure_1 = Data_case_target %>% dplyr::filter(Panel == "NOP_T")
      g1 = ggplot(Data_figure_1, aes(x=Mismatch_Rate_Tumor, fill=Variant_Type)) +
        geom_histogram(boundary=0, binwidth = 0.025, position="stack") +
        scale_x_continuous(limits = c(0,1),
                           breaks = seq(0, 1, by = 0.1),
                           labels = paste0(seq(0, 100, by = 10), "%")) +
        theme_classic()+
        labs(x = "Variant allele frequency (%)",
             y = "Counts",
             title = "Variant allele frequency of somatic mutations in tumor panel")
      Data_figure_2 = Data_case_target %>% dplyr::filter(Panel == "NOP_N")
      g2 = ggplot(Data_figure_2, aes(x=Mismatch_Rate_Normal, fill=Variant_Type)) +
        geom_histogram(boundary=0, binwidth = 0.025, position="stack") +
        scale_x_continuous(limits = c(0,1),
                           breaks = seq(0, 1, by = 0.1),
                           labels = paste0(seq(0, 100, by = 10), "%")) +
        theme_classic()+
        labs(x = "Variant allele frequency (%)",
             y = "Counts",
             title = "Variant allele frequency of germline mutations in normal panel")
      Data_figure_3 = Data_case_target %>% dplyr::filter(Panel == "NOP_N")
      g3 = ggplot(Data_figure_3, aes(x=Mismatch_Rate_Tumor, fill=Variant_Type)) +
        geom_histogram(boundary=0, binwidth = 0.025, position="stack") +
        scale_x_continuous(limits = c(0,1),
                           breaks = seq(0, 1, by = 0.1),
                           labels = paste0(seq(0, 100, by = 10), "%")) +
        theme_classic()+
        labs(x = "Variant allele frequency (%)",
             y = "Counts",
             title = "Variant allele frequency of germline mutations in tumor panel")
      incProgress(1 / 8)
      
      output$figure_VAF_histogram = renderPlot({
        grid.arrange(g1,g2,g3,nrow = 3, ncol=1)
      })
    })
  })
  
  observeEvent(input$oncoprint, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      output$figure_oncoprint = renderPlot({
       fun_oncoprint(Data_case_target,
                     names(sort(table(Data_case_target$Gene),
                                decreasing = T)),
                     input$gene,
                     input$gene_no,
                     input$oncoprint_option,
                     input$mid_age)
     })
     incProgress(1 / 8)
     output$figure_lolliplot2 = renderPlot({
       withProgress(message = "Internet access is necessary", {
         lolliplot_gene = input$lolliplot_gene
         if(is.null(lolliplot_gene)){
           lolliplot_gene = "TP53"
         } else if(lolliplot_gene == ""){
           lolliplot_gene = "TP53"
         }
         data_lolliplot = Data_case_target %>%
           dplyr::select(Chr,
                         Pos,
                         Ref,
                         Alt,
                         ID,
                         Gene,
                         Variant_Type,
                         Panel,
                         HGVSp)
         data_lolliplot = data_lolliplot %>%
           dplyr::filter(!is.na(HGVSp)) %>%
           dplyr::filter(HGVSp != "") %>%
           dplyr::filter(Gene == lolliplot_gene)

         if(length(data_lolliplot$Chr) == 0){
           gg_empty()
         } else {
           var<-unique(data_lolliplot[!duplicated(data_lolliplot),])#remove duplicates
           
           var.freq<-plyr::count(var,c("Gene","HGVSp","Variant_Type","Panel"))
           var.freq$aanum = as.integer(gsub("=","",gsub("([A-Z])","",gsub("([a-z])","",str_sub(var.freq$HGVSp, 4,7)))))
           var.aanum<-var.freq$aanum
           var.plot.data<-cbind(var.freq,var.aanum)
           var.plot.data = var.plot.data[var.plot.data$var.aanum >=1 & is.finite(var.plot.data$var.aanum) & !is.na(var.plot.data$var.aanum),]
           
           var.plot<-isolate(var.plot.data)
           var.plot<-var.plot[var.plot$Gene==lolliplot_gene,]
           var.plot<-var.plot[order(var.plot$var.aanum),]
           var.plot$amino.acid.change<-as.character(var.plot$HGVSp)
           var.plot$Variant_Classification<-as.character(var.plot$Variant_Type)
           var.plot$Hugo_Symbol = var.plot$Gene
           var.plot$freq = ifelse(var.plot$Panel == "NOP_N", var.plot$freq, -var.plot$freq)
           incProgress(1 / 4)
  
           p<-ggplot(var.plot,aes(var.aanum,freq,color=Variant_Classification,label=amino.acid.change)) +
             geom_segment(aes(x=var.aanum,y=0,xend=var.aanum,yend=freq),
                          color=ifelse(var.plot$freq>=input$lolliplot_no,"orange","grey50"),
                          linewidth=ifelse(var.plot$freq>=input$lolliplot_no,1.3,0.7)) +
             geom_point(size=3) +
             geom_text_repel(nudge_y=0.2,
                             color=ifelse(abs(var.plot$freq)>=input$lolliplot_no,"orange","NA"),
                             size=ifelse(abs(var.plot$freq)>=input$lolliplot_no,5,5),
                             fontface="bold", max.overlaps=Inf) +
             theme_classic()
           proteins_acc<-read.table(file("source/UniProt.txt",
                                         encoding='UTF-8-BOM'),header=T)
           if(length(proteins_acc[proteins_acc$Hugo_Symbol==lolliplot_gene,2]) == 1){
             proteins_acc<-proteins_acc[proteins_acc$Hugo_Symbol==lolliplot_gene,2]
             proteins_acc_url<-gsub(" ","%2C",proteins_acc)
             baseurl<-"https://www.ebi.ac.uk/proteins/api/features?offset=0&size=100&accession="
             url<-paste0(baseurl,proteins_acc_url)
             incProgress(1 / 6)
             flag_lolliplot = 0
             if(file.exists(paste0("source/lolliplot/", lolliplot_gene, ".rda"))){
               load(paste0("source/lolliplot/", lolliplot_gene, ".rda"))
               flag_lolliplot = 1
             } else {
               prots_feat<-try(GET(url,accept_json()), silent = FALSE)
               if (class(prots_feat) != "try-error"){
                 flag_lolliplot = 1
                 save(prots_feat, file=paste0("source/lolliplot/", lolliplot_gene, ".rda"))
               }
             }
             if (flag_lolliplot == 1){
               prots_feat_red<-(httr::content(prots_feat))
               incProgress(1 / 6)
               features_total_plot<-NULL
               for(i in 1:length(prots_feat_red)){ 
                 features_temp<-drawProteins::extract_feat_acc(prots_feat_red[[i]])#the extract_feat_acc() function takes features into a data.frame
                 features_temp$order<-i # this order is needed for plotting later
                 features_total_plot<-rbind(features_total_plot,features_temp)
               }
               plot_start<-0#starts 0
               plot_end<-max(features_total_plot$end)
               if("CHAIN"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="CHAIN",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.5,ymax=0.5),
                             colour="grey",
                             fill="grey",
                             inherit.aes=F)
               }
               incProgress(1 / 6)
               if("DNA_BIND"%in%(unique(features_total_plot$type))) {
                 features_total_plot[features_total_plot$type=="DNA_BIND","description"] <- features_total_plot[features_total_plot$type=="DNA_BIND","type"]
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="DNA_BIND",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.8,ymax=0.8,fill=description),
                             inherit.aes=F)
               }
               if("DOMAIN"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="DOMAIN",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.8,ymax=0.8,fill=description),
                             inherit.aes=F)
               }
               if("MOTIF"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="MOTIF",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.8,ymax=0.8,fill=description),
                             inherit.aes=F)
               }
               if("REPEAT"%in%(unique(features_total_plot$type))){
                 p <- p +
                   geom_rect(data=features_total_plot[features_total_plot$type=="REPEAT",],
                             mapping=aes(xmin=begin,xmax=end,ymin=-0.8,ymax=0.8,fill=description),
                             inherit.aes=F)
               }
               p <- p +
                 scale_x_continuous(breaks=round(seq(plot_start,plot_end,by=50)),name="Amino acid number")
             }
           }
           p <- p +
             theme(plot.title=element_text(face="bold",size=(15),hjust=0),axis.text.x=element_text(angle=90,hjust=1)) +
             labs(y="Mutation frequency in our dataset, upper: germline, lower: somatic",
                  title=paste("Mutation frequency at ",lolliplot_gene," in the dataset, upper: germline, lower: somatic",sep="")) +
             scale_y_continuous(breaks=seq(floor(min(var.plot$freq)/10)*10,
                                           ceiling(max(var.plot$freq)/10)*10,
                                           max(floor(max(abs(var.plot$freq))/100)*10,10)),
                                labels=abs(seq(floor(min(var.plot$freq)/10)*10,
                                           ceiling(max(var.plot$freq)/10)*10,
                                           max(floor(max(abs(var.plot$freq))/100)*10,10))),name="Frequency")
           print(p)
           incProgress(1 / 6)
         }
       })
     })
     incProgress(1 / 8)

     Data_table = Data_case_target %>%
       dplyr::arrange(ID) %>%
       dplyr::arrange(Panel) %>%
       dplyr::distinct(ID, .keep_all = TRUE)
     incProgress(1 / 8)
     colnames_tmp = colnames(Data_table)
     colnames_tmp[colnames_tmp == "Panel"] = "Somatic_Germline"
     colnames(Data_table) = colnames_tmp
     Data_table$Somatic_Germline = ifelse(
       Data_table$Somatic_Germline == "NOP_T",
       "Somatic only", "GPV (+)"
     )

     gene_list = unique(c(input$gene,
                   names(sort(table(Data_case_target$Gene),
                            decreasing = T))))
     gene_list = gene_list[gene_list %in% unique(Data_case_target$Gene)]
     gene_list = gene_list[1:min(input$gene_no, length(gene_list))]
     gene_table = data.frame(matrix(rep(rep("", length(gene_list)),
                                        length(Data_table$ID)),
                                    nrow=length(Data_table$ID)))
     rownames(gene_table) = Data_table$ID
     colnames(gene_table) = gene_list
     incProgress(1 / 8)
     for(i in 1:length(gene_list)){
       tmp_mut = Data_case_target %>%
         dplyr::filter(Gene == gene_list[i])
       ID_mut = tmp_mut$ID
       Variant_mut = tmp_mut$HGVSp
       for(j in 1:length(ID_mut)){
         if(gene_table[ID_mut[j],i] == ""){
           gene_table[ID_mut[j],i] = Variant_mut[j]
         } else{
           gene_table[ID_mut[j],i] = paste(gene_table[ID_mut[j],i], Variant_mut[j], sep=",")
         }
       }
     }
     incProgress(1 / 8)
     gene_table$ID = rownames(gene_table)

     Data_table = Data_table %>% dplyr::select(
       ID, pathology_top, pathology_detail, age, YoungOld, sex, Somatic_Germline, sampling_site, tumor_content,
       smoking_history, alcohol, double_cancer, multiple_nodule, cancer_family_history,
       sampling_to_test)
     Data_table = left_join(Data_table,
                                  gene_table,
                                  by = "ID")

     output$table_patient = DT::renderDataTable(Data_table,
                                                server = FALSE,
                                                filter = 'top', 
                                                extensions = c('Buttons'), 
                                                options = list(pageLength = 100, 
                                                               scrollX = TRUE,
                                                               scrollY = "1000px",
                                                               scrollCollapse = TRUE,
                                                               dom="Blfrtip",
                                                               buttons = c('csv', 'copy')))
     incProgress(1 / 1)
    })
  })

  observeEvent(input$mut_subtype, {
    withProgress(message = sample(nietzsche)[1], {
      output$figure_mut_all = renderPlot({
        Data_case_target = Data_case()
        gene_to_analyze = unique(c(input$gene,
                              names(sort(table(Data_case_target$Gene),
                                         decreasing = T))))
        gene_to_analyze = gene_to_analyze[gene_to_analyze %in% unique(Data_case_target$Gene)]
        gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Diseases = sort(unique(Data_case_target$pathology_top))
        Summary_Gene_alteration = data.frame(matrix(0,
                                                    nrow=length(Diseases),
                                                    ncol=length(gene_to_analyze)))
        colnames(Summary_Gene_alteration) = gene_to_analyze
        rownames(Summary_Gene_alteration) = Diseases
        
        for(i in Diseases){
          Data_tmp = Data_case_target %>%
            dplyr::filter(pathology_top == i)
          Data_tmp = unique(Data_tmp$ID)
          patient_no = histology_number[names(histology_number) == i]
          
          for(j in gene_to_analyze){
            Summary_Gene_alteration[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  ID %in% Data_tmp))$Gene) / patient_no * 100
          }
        }
        
        Data_tmp = Summary_Gene_alteration
        Data_tmp$Disease = rownames(Data_tmp)
        Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
        Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
        ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
          geom_tile(aes(fill = freq), color = "black",
                    linetype = 1) + 
          geom_text(aes(label = round(freq, 0))) +
          scale_fill_gradient(low = "white", high = "red", limit=c(0,100), name="Frequency (%)") +
          theme_classic() +
          labs(title = "Frequently mutated genes and diagnoses") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1),
                axis.title.x = element_blank(),
                axis.title.y = element_blank(),
                axis.ticks.x = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.x = element_blank(),
                axis.line.y = element_blank())
      })
      output$figure_mut_somatic = renderPlot({
        Data_case_target = Data_case() %>% dplyr::filter(Panel == "NOP_T")
        gene_to_analyze = unique(c(input$gene,
                                   names(sort(table(Data_case_target$Gene),
                                              decreasing = T))))
        gene_to_analyze = gene_to_analyze[gene_to_analyze %in% unique(Data_case_target$Gene)]
        gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Diseases = sort(unique(Data_case_target$pathology_top))
        Summary_Gene_alteration = data.frame(matrix(0,
                                                    nrow=length(Diseases),
                                                    ncol=length(gene_to_analyze)))
        colnames(Summary_Gene_alteration) = gene_to_analyze
        rownames(Summary_Gene_alteration) = Diseases
        
        for(i in Diseases){
          Data_tmp = Data_case_target %>%
            dplyr::filter(pathology_top == i)
          Data_tmp = unique(Data_tmp$ID)
          patient_no = histology_number[names(histology_number) == i]
          for(j in gene_to_analyze){
            Summary_Gene_alteration[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  ID %in% Data_tmp))$Gene) / patient_no * 100
          }
        }
        
        Data_tmp = Summary_Gene_alteration
        Data_tmp$Disease = rownames(Data_tmp)
        Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
        Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
        ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
          geom_tile(aes(fill = freq), color = "black",
                    linetype = 1) + 
          geom_text(aes(label = round(freq, 0))) +
          scale_fill_gradient(low = "white", high = "red", limit=c(0,100), name="Frequency (%)") +
          theme_classic() +
          labs(title = "Frequent somatic mutation and diagnoses") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1),
                axis.title.x = element_blank(),
                axis.title.y = element_blank(),
                axis.ticks.x = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.x = element_blank(),
                axis.line.y = element_blank())
      })
      output$figure_mut_germline = renderPlot({
        Data_case_target = Data_case() %>% dplyr::filter(Panel == "NOP_N")
        gene_to_analyze = unique(c(input$gene,
                                   names(sort(table(Data_case_target$Gene),
                                              decreasing = T))))
        gene_to_analyze = gene_to_analyze[gene_to_analyze %in% unique(Data_case_target$Gene)]
        gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Diseases = sort(unique(Data_case_target$pathology_top))
        Summary_Gene_alteration = data.frame(matrix(0,
                                                    nrow=length(Diseases),
                                                    ncol=length(gene_to_analyze)))
        colnames(Summary_Gene_alteration) = gene_to_analyze
        rownames(Summary_Gene_alteration) = Diseases
        
        for(i in Diseases){
          Data_tmp = Data_case_target %>%
            dplyr::filter(pathology_top == i)
          Data_tmp = unique(Data_tmp$ID)
          patient_no = histology_number[names(histology_number) == i]
          for(j in gene_to_analyze){
            Summary_Gene_alteration[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  ID %in% Data_tmp))$Gene) / patient_no * 100
          }
        }
        
        Data_tmp = Summary_Gene_alteration
        Data_tmp$Disease = rownames(Data_tmp)
        Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
        Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
        ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
          geom_tile(aes(fill = freq), color = "black",
                    linetype = 1) + 
          geom_text(aes(label = round(freq, 0))) +
          scale_fill_gradient(low = "white", high = "red", limit=c(0,100), name="Frequency (%)") +
          theme_classic() +
          labs(title = "Frequent germline mutation and diagnoses") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1),
                axis.title.x = element_blank(),
                axis.title.y = element_blank(),
                axis.ticks.x = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.x = element_blank(),
                axis.line.y = element_blank())
      })
      output$figure_mut_conversion_rate = renderPlot({
        Data_case_target = Data_case() %>%
          dplyr::filter(
            Panel == "NOP_T" |
              Mismatch_Rate_Tumor >= 0.05
          )
        gene_to_analyze = unique(c(input$gene,
                                   names(sort(table(Data_case_target$Gene),
                                              decreasing = T))))
        gene_to_analyze = gene_to_analyze[gene_to_analyze %in% unique(Data_case_target$Gene)]
        #gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Diseases = sort(unique(Data_case_target$pathology_top))
        Summary_Gene_alteration = data.frame(matrix(0,
                                                    nrow=length(Diseases),
                                                    ncol=length(gene_to_analyze)))
        colnames(Summary_Gene_alteration) = gene_to_analyze
        rownames(Summary_Gene_alteration) = Diseases
        Summary_Gene_alteration_raw = Summary_Gene_alteration
        Summary_Gene_alteration_all = Summary_Gene_alteration
        
        for(i in Diseases){
          Data_tmp = Data_case_target %>%
            dplyr::filter(pathology_top == i)
          Data_tmp = unique(Data_tmp$ID)
          patient_no = histology_number[names(histology_number) == i]
          for(j in gene_to_analyze){
            Summary_Gene_alteration[i,j] =
              fun_zero(length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  Panel == "NOP_N" &
                  ID %in% Data_tmp))$Gene),
                length((Data_case_target %>% dplyr::filter(
                  Gene == j &
                    ID %in% Data_tmp))$Gene)) * 100
            Summary_Gene_alteration_raw[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  Panel == "NOP_N" &
                  ID %in% Data_tmp))$Gene)
            Summary_Gene_alteration_all[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  ID %in% Data_tmp))$Gene)
          }
        }
        
        GPV_count = colSums(Summary_Gene_alteration_raw)
        All_count = colSums(Summary_Gene_alteration_all)
        conversion_rate_gene = fun_zero(GPV_count, All_count) * 100
        conversion_rate_gene = data.frame(conversion_rate_gene)
        colnames(conversion_rate_gene) = "conversion_rate"
        conversion_rate_gene$GPV_count = GPV_count
        conversion_rate_gene$All_count = All_count
        conversion_rate_gene$text = paste0(conversion_rate_gene$GPV_count, "/", conversion_rate_gene$All_count)
        conversion_rate_gene = conversion_rate_gene %>%
          dplyr::arrange(-All_count) %>%
          dplyr::arrange(-conversion_rate)
        gene_names = rownames(conversion_rate_gene)
        conversion_rate_gene$Gene = factor(gene_names, levels = rev(gene_names))

        gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Data_tmp = Summary_Gene_alteration[,colnames(Summary_Gene_alteration) %in% gene_to_analyze]
        Data_tmp$Disease = rownames(Data_tmp)
        Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
        Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
        g1 = ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
          geom_tile(aes(fill = freq), color = "black",
                    linetype = 1) + 
          geom_text(aes(label = round(freq, 0))) +
          scale_fill_gradient(low = "white", high = "red", limit=c(0,100), name="Conversion rate (%)") +
          theme_classic() +
          labs(title = "Germline conversion rate of somatic variants and diagnoses") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1),
                axis.title.x = element_blank(),
                axis.title.y = element_blank(),
                axis.ticks.x = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.x = element_blank(),
                axis.line.y = element_blank())
        g2 = ggplot(conversion_rate_gene, aes(x=Gene, y=conversion_rate, label = text)) +
          geom_bar(stat = "identity") +
          coord_flip() +
          theme_classic() +
          ylim(c(0,110)) + 
          labs(x = "",
               y = "Germline conversion rate (%)",
               title = "Germline conversion rate of somatic variants in tumor panel") +
        geom_text(aes(x=Gene, y=conversion_rate,label = text), hjust=-0.3, vjust = 0.5)
        grid.arrange(g1, g2, ncol = 1, nrow = 2)
      })

      output$figure_mut_false_negative = renderPlot({
        Data_case_target = Data_case() %>%
          dplyr::filter(
            Panel == "NOP_N")
        gene_to_analyze = unique(c(input$gene,
                                   names(sort(table(Data_case_target$Gene),
                                              decreasing = T))))
        gene_to_analyze = gene_to_analyze[gene_to_analyze %in% unique(Data_case_target$Gene)]
        #gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Diseases = sort(unique(Data_case_target$pathology_top))
        Summary_Gene_alteration = data.frame(matrix(0,
                                                    nrow=length(Diseases),
                                                    ncol=length(gene_to_analyze)))
        colnames(Summary_Gene_alteration) = gene_to_analyze
        rownames(Summary_Gene_alteration) = Diseases
        Summary_Gene_alteration_raw = Summary_Gene_alteration
        Summary_Gene_alteration_all = Summary_Gene_alteration
        
        for(i in Diseases){
          Data_tmp = Data_case_target %>%
            dplyr::filter(pathology_top == i)
          Data_tmp = unique(Data_tmp$ID)
          patient_no = histology_number[names(histology_number) == i]
          for(j in gene_to_analyze){
            Summary_Gene_alteration[i,j] =
              fun_zero(length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  Mismatch_Rate_Tumor < 0.05 &
                  ID %in% Data_tmp))$Gene),
                length((Data_case_target %>% dplyr::filter(
                  Gene == j &
                    ID %in% Data_tmp))$Gene)) * 100
            Summary_Gene_alteration_raw[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  Mismatch_Rate_Tumor < 0.05 &
                  ID %in% Data_tmp))$Gene)
            Summary_Gene_alteration_all[i,j] =
              length((Data_case_target %>% dplyr::filter(
                Gene == j &
                  ID %in% Data_tmp))$Gene)
          }
        }
        
        GPV_count = colSums(Summary_Gene_alteration_raw)
        All_count = colSums(Summary_Gene_alteration_all)
        conversion_rate_gene = fun_zero(GPV_count, All_count) * 100
        conversion_rate_gene = data.frame(conversion_rate_gene)
        colnames(conversion_rate_gene) = "conversion_rate"
        conversion_rate_gene$GPV_count = GPV_count
        conversion_rate_gene$All_count = All_count
        conversion_rate_gene$text = paste0(conversion_rate_gene$GPV_count, "/", conversion_rate_gene$All_count)
        conversion_rate_gene = conversion_rate_gene %>%
          dplyr::arrange(-All_count) %>%
          dplyr::arrange(-conversion_rate)
        gene_names = rownames(conversion_rate_gene)
        conversion_rate_gene$Gene = factor(gene_names, levels = rev(gene_names))

        gene_to_analyze = gene_to_analyze[1:min(length(unique(Data_case_target$Gene)),input$gene_no)]
        Data_tmp = Summary_Gene_alteration[,colnames(Summary_Gene_alteration) %in% gene_to_analyze]
        Data_tmp$Disease = rownames(Data_tmp)
        Data_tmp = Data_tmp %>% gather(value = "freq", key = Gene, -Disease)
        Data_tmp <- transform(Data_tmp, Disease= factor(Disease, levels = sort(unique(Disease), decreasing = TRUE)))
        g1 = ggplot(Data_tmp, aes(as.factor(Gene), as.factor(Disease))) +
          geom_tile(aes(fill = freq), color = "black",
                    linetype = 1) + 
          geom_text(aes(label = round(freq, 0))) +
          scale_fill_gradient(low = "white", high = "red", limit=c(0,100), name="False-negative rate (%)") +
          theme_classic() +
          labs(title = "False-negative GPV in tumor panel and diagnoses") +
          theme(axis.text.x = element_text(angle = 45, hjust = 1),
                axis.title.x = element_blank(),
                axis.title.y = element_blank(),
                axis.ticks.x = element_blank(),
                axis.ticks.y = element_blank(),
                axis.line.x = element_blank(),
                axis.line.y = element_blank())
        g2 = ggplot(conversion_rate_gene, aes(x=Gene, y=conversion_rate, label = text)) +
          geom_bar(stat = "identity") +
          coord_flip() +
          theme_classic() +
          ylim(c(0,110)) + 
          labs(x = "",
               y = "False-negative rate (%)",
               title = "False-negative rate of germline variants in tumor panel") +
          geom_text(aes(x=Gene, y=conversion_rate,label = text), hjust=-0.3, vjust = 0.5)
        grid.arrange(g1, g2, ncol = 1, nrow = 2)
      })
    })
  })

  observeEvent(input$PGPV_prediction, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      incProgress(1 / 13)
      Data_forest = Data_case_target %>%
          dplyr::select(age,
                        YoungOld,
                        Gene,
                        Mismatch_Rate_Tumor,
                        gnomADg_AF_eas,
                        ToMMo_AF,
                        sex,
                        pathology_top,
                        sampling_site,
                        tumor_content,
                        smoking_history,
                        alcohol,
                        double_cancer,
                        multiple_nodule,
                        cancer_family_history,
                        Variant_Type,
                        Panel,
                        Oncogene_TSG,
                        Conversion_rate,
                        confirmation_test
                        )
      Data_forest = Data_forest %>% dplyr::filter(
        Mismatch_Rate_Tumor >= 0.05
      )
      frequent_genes = sort(table(Data_forest$Gene),decreasing = T)
      frequent_genes_names = names(frequent_genes[frequent_genes>=50])
      frequent_organs = sort(table(Data_forest$pathology_top),decreasing = T)
      frequent_organs_names = names(frequent_organs[frequent_organs>=50])
      Data_forest = Data_forest %>% dplyr::mutate(
        VAF = case_when(
            Mismatch_Rate_Tumor < 0.3  ~ "5_29",
          TRUE ~ "30_"
        ),
        relative_VAF = case_when(
          fun_zero(Mismatch_Rate_Tumor,tumor_content) < 0.01 ~ "0_99",
          TRUE ~ "100_"
        ),
        Gene_type = case_when(
          Gene %in% frequent_genes_names ~ Gene,
          Oncogene_TSG == "Both" & Conversion_rate == "High" ~ "Onc&TSG_H",
          Oncogene_TSG == "Both" & Conversion_rate == "Middle" ~ "Onc&TSG_M",
          Oncogene_TSG == "Both" & Conversion_rate == "Low" ~ "Onc&TSG_L",
          Oncogene_TSG == "Both" & Conversion_rate == "Unknown" ~ "Onc&TSG_U",
          Oncogene_TSG == "Oncogene" & Conversion_rate == "High" ~ "Onc_H",
          Oncogene_TSG == "Oncogene" & Conversion_rate == "Middle" ~ "Onc_M",
          Oncogene_TSG == "Oncogene" & Conversion_rate == "Low" ~ "Onc_L",
          Oncogene_TSG == "Oncogene" & Conversion_rate == "Unknown" ~ "Onc_U",
          Oncogene_TSG == "TSG" & Conversion_rate == "High" ~ "TSG_H",
          Oncogene_TSG == "TSG" & Conversion_rate == "Middle" ~ "TSG_M",
          Oncogene_TSG == "TSG" & Conversion_rate == "Low" ~ "TSG_L",
          Oncogene_TSG == "TSG" & Conversion_rate == "Unknown" ~ "TSG_U",
          TRUE ~ "Other"
        ),
        Organ_type = case_when(
          pathology_top %in% frequent_organs_names ~ pathology_top,
          TRUE ~ "Rare_organs"
        ),
        Mut_in_healthy = case_when(
          gnomADg_AF_eas > 0 | ToMMo_AF > 0 ~ "Yes",
          TRUE ~ "No"
        ),
        Mut_Pattern = case_when(
          Variant_Type %in% c("DNP_G", "DNP_S", "TNP_G", "TNP_S", "ONP_G", "ONP_S", "Other") ~ "Other",
          Variant_Type %in% c("SNP_G", "SNP_S") ~ "SNP",
          Variant_Type %in% c("INS_G", "INS_S") ~ "INS",
          Variant_Type %in% c("DEL_G", "DEL_S") ~ "DEL",
          TRUE ~ "Other"
        ),
        T_N = case_when(
          Panel == "NOP_T" ~ 0,
          TRUE ~ 1
        )
      )

      Data_forest_tmp__ = Data_forest %>%
        dplyr::filter(Mut_Pattern != "Other" &
                      Gene_type != "Other" &
                      !is.na(tumor_content) &
                      sampling_site != "Unknown" &
                      smoking_history != "Unknown" &
                      alcohol != "Unknown" &
                      double_cancer != "Unknown" &
                      multiple_nodule != "Unknown" &
                      cancer_family_history != "Unknown"
        )
      
      Disease_tmp = unique(sort(Data_forest_tmp__$Organ_type))
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp_2_ = Data_forest_tmp__ %>% dplyr::filter(Organ_type == Disease_tmp[i])
        if(sum(Data_forest_tmp_2_$T_N == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::mutate(Organ_type = case_when(
              Organ_type == Disease_tmp[i] ~ "Rare_organs",
              TRUE ~ Organ_type
            )
            )
        }
      }
      Data_figure =  Data_forest_tmp__ %>%
        dplyr::mutate(
          relative_VAF =  fun_zero(Mismatch_Rate_Tumor,tumor_content)*100,
          T_N = as.factor(T_N)
        )
      g_basic_1 = Data_figure %>%
        ggplot(aes(x = Mismatch_Rate_Tumor, fill = T_N)) +
        geom_histogram(boundary=0, binwidth = 0.05, position="stack") +
        theme_classic()+
        labs(x = "Variant allele frequency",
             y = "Counts",
             title = "Variant allele frequency in tumor panel",
             fill = "Germline or somatic") +
        scale_fill_discrete(labels = c("0" = "Somatic", "1" ="Germline")) +
        geom_vline(xintercept=0.3, linetype = "dashed",colour = "blue") +
        scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.1))
      g_basic_2 = Data_figure %>%
        ggplot(aes(x = relative_VAF, fill = T_N)) +
        geom_histogram(boundary=0, binwidth = 0.1, position="stack") +
        theme_classic()+
        labs(x = "Relative variant allele frequency",
             y = "Counts",
             title = "Variant allele frequency to tumor content ratio in tumor panel",
             fill = "Germline or somatic") +
        scale_fill_discrete(labels = c("0" = "Somatic", "1" ="Germline")) +
        geom_vline(xintercept=1, linetype = "dashed",colour = "blue") +
        scale_x_continuous(limits = c(0, 8), breaks = seq(0, 8, 1))
      output$figure_GPV_basic_data = renderPlot({
        grid.arrange(g_basic_1, g_basic_2, ncol = 1, nrow = 2)
      })
      
      Data_forest_tmp_5 = Data_forest_tmp__ %>%
        dplyr::select(-Gene, -relative_VAF, -gnomADg_AF_eas, -ToMMo_AF, -Panel,-YoungOld,
                      -pathology_top, -VAF, -Oncogene_TSG, -Variant_Type, -Conversion_rate)
      Data_forest_tmp_7 = Data_forest_tmp__ %>%
        dplyr::select(-Gene, -Mismatch_Rate_Tumor, -gnomADg_AF_eas, -ToMMo_AF, -Panel,-age,
                      -pathology_top, -tumor_content, -Oncogene_TSG, -Variant_Type, -Conversion_rate)
      Organ_data = data.frame(sort(unique(Data_forest_tmp_5$Organ_type)))
      colnames(Organ_data) = c("Organ_type")
      save(file = "source/Organ_data.rda", Organ_data)
      Gene_data = data.frame(sort(unique(Data_forest_tmp_5$Gene_type)))
      colnames(Gene_data) = c("Gene_type")
      save(file = "source/Gene_data.rda", Gene_data)
      Data_forest_tmp_5 = data.frame( lapply(Data_forest_tmp_5, as.factor) )
      Data_forest_tmp_7 = data.frame( lapply(Data_forest_tmp_7, as.factor) )
      Data_forest_tmp_5$age = as.numeric(as.character(Data_forest_tmp_5$age))
      Data_forest_tmp_5$Mismatch_Rate_Tumor = as.numeric(as.character(Data_forest_tmp_5$Mismatch_Rate_Tumor))
      Data_forest_tmp_5$tumor_content = as.numeric(as.character(Data_forest_tmp_5$tumor_content))
      Data_forest_tmp_5$Organ_type <- relevel(Data_forest_tmp_5$Organ_type, ref=names(sort(table(Data_forest_tmp_5$Organ_type),decreasing = T))[[1]]) 
      Data_forest_tmp_7$Organ_type <- relevel(Data_forest_tmp_7$Organ_type, ref=names(sort(table(Data_forest_tmp_7$Organ_type),decreasing = T))[[1]]) 
      if(length(colnames(Data_forest_tmp_7)) > 2){
        Data_forest_tmp_5_ = Data_forest_tmp_5 %>% dplyr::select(-confirmation_test)
        Data_forest_tmp_7_ = Data_forest_tmp_7 %>% dplyr::select(-confirmation_test)
        m1 <- glm(T_N ~., data = Data_forest_tmp_7_, family = binomial(link = "logit"))
        final_mv_reg <- m1 %>%
          stats::step(direction = "backward", trace = FALSE)
      }
      output$figure_Odds = render_gt({
        if(length(colnames(Data_forest_tmp_7)) > 1){
          univ_tab <- Data_forest_tmp_7 %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = glm,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = T_N,
              method.args = list(family = binomial),  ## 実行したい glm のタイプを定義（ここではロジスティック）
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels()
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(
                exponentiate = TRUE
              ) |>
              add_global_p() |>
              add_q() |>
              bold_p() |>
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption("Factors predicting germline origin") |> as_gt()
          } else {
            univ_tab |>
              modify_caption("Factors predicting germline origin, no significant factor in multivariable analysis") |> as_gt()
          }
        }
      })

      Data_forest_tmp_8 = Data_forest_tmp_7
      if(length(colnames(Data_forest_tmp_8)) > 1){
        if(!is.null(final_mv_reg$xlevels)){
          Data_forest_tmp_treat = Data_forest_tmp_8 %>% dplyr::select(c("T_N", names(final_mv_reg$xlevels)))
          if(length(colnames(Data_forest_tmp_treat)) > 1){
            dd <- datadist(Data_forest_tmp_treat) 
            options(datadist=dd)
            formula_treat = formula(paste0("T_N ~ ",paste(colnames(Data_forest_tmp_treat)[colnames(Data_forest_tmp_treat)!="T_N"], collapse="+")))
            m2 <- lrm(formula_treat,
                      data = Data_forest_tmp_treat,x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)
            save(m2, file = "source/m2.rda")
            # error in rms package
            val <- try(rms::validate(m2, B=500), silent = FALSE)
            if (class(val) == "try-error") {
              val = rms::validate(m2, B=500)
            }
            # do not delete
            cal = calibrate(m2, B=500)
            options(datadist=NULL)
            log_nomogram <- nomogram(m2, fun = plogis, fun.at=c(.001,.01,.1,.5,.9,.99,.999), lp=F, funlabel="Germline origin")
          }
        }
      }
      
      output$figure_nomogram = renderPlot({
        if(length(colnames(Data_forest_tmp_8)) > 1){
          if(!is.null(final_mv_reg$xlevels)){
            if(length(colnames(Data_forest_tmp_treat)) > 1){
              par(mfcol = c(2, 1))
              plot(cal, lwd=2, lty=1, 
                   cex.lab=1.2, cex.axis=1, cex.main=1.2, cex.sub=0.6, 
                   xlim=c(0, 1), ylim= c(0, 1), 
                   xlab="Nomogram-Predicted Probability of germline origin", 
                   ylab="Actual germline variants (proportion)",
                   legend=FALSE)
              #lines(cal[, c(1:3)], type ="o", lwd=1, pch=16, col=c("#00468BFF"))
              abline(0, 1, lty=3, lwd=2,  col=c("#224444")) 
              text(x=.6, y=.0, adj = c(0,0), paste0("Germline conversion rate","\n",
                                      "Nagelkerke R2 = ", round(val[2,5], digits=3),'\n',
                                      "500-time-bootstrapped-concordance index = ", round(((val[1,5] + 1) / 2), digits=3),"\n",
                                      "Intercept = ",round(val[3,5], digits=3),"\n",
                                      "Slope = ", round(val[4,5], digits=3)))
              legend(x=.8, y=.2, legend=c("Apparent", "Bias-corrected", "Ideal"), 
                     lty=c(3, 1, 2), bty="n")
              text(x=-0.0, y=.4, cex=1, adj = c(0,0),
                   paste0("Gene type\n",
                          paste(log_nomogram$Gene_type$Gene_type, collapse = "\n")))
              text(x=.12, y=.4, cex=1, adj = c(0,0),
                   paste0("Point\n",
                          paste(round(log_nomogram$Gene_type$points,digits = 0), collapse = "\n")))
              plot(log_nomogram)
            } else {
              gg_empty()
            }
          } else {
            gg_empty()
          }
        } else {
          gg_empty()
        }
      })
      
      if(length(colnames(Data_forest_tmp_8)) > 1){
        if(!is.null(final_mv_reg$xlevels)){
          if(length(colnames(Data_forest_tmp_treat)) > 1){
            Data_forest_tmp_treat$patientid = 1:length(Data_forest_tmp_treat$T_N)
            Data_forest_tmp_8$patientid = 1:length(Data_forest_tmp_8$T_N)
            dca_thresholds = seq(0, 1.00, 0.05)
            set.seed(1212)            
            # create a 10-fold cross validation set, 1 repeat which is the base case, change to suit your use case
            cross_validation_samples <- rsample::vfold_cv(Data_forest_tmp_treat, strata = "T_N", v = 10, repeats = 1)
  
            df_crossval_predictions <- 
              cross_validation_samples %>% 
              dplyr::mutate(
                glm_analysis = c(list(lrm(formula = formula_treat, data = rsample::analysis(splits[[1]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[2]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[3]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[4]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[5]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[6]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[7]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[8]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[9]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[10]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)))
              )
            df_prediction_id = c(rsample::assessment(df_crossval_predictions$splits[[1]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[2]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[3]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[4]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[5]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[6]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[7]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[8]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[9]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[10]])$patientid
            )
            
            df_prediction_score = c(predict(df_crossval_predictions$glm_analysis[[1]], rsample::assessment(df_crossval_predictions$splits[[1]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[2]], rsample::assessment(df_crossval_predictions$splits[[2]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[3]], rsample::assessment(df_crossval_predictions$splits[[3]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[4]], rsample::assessment(df_crossval_predictions$splits[[4]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[5]], rsample::assessment(df_crossval_predictions$splits[[5]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[6]], rsample::assessment(df_crossval_predictions$splits[[6]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[7]], rsample::assessment(df_crossval_predictions$splits[[7]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[8]], rsample::assessment(df_crossval_predictions$splits[[8]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[9]], rsample::assessment(df_crossval_predictions$splits[[9]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[10]], rsample::assessment(df_crossval_predictions$splits[[10]]),type = "fitted")
            )
            df_prediction = data.frame(df_prediction_id, df_prediction_score)
            colnames(df_prediction) = c("patientid", ".fitted")
          
          df_cv_pred <-
              Data_forest_tmp_treat %>%
            dplyr::left_join(
              df_prediction,
              by = 'patientid'
            ) %>%
            dplyr::left_join(
              Data_forest_tmp_8 %>% dplyr::select(patientid, confirmation_test),
              by = 'patientid'
            )
          set.seed(1212)
          Data_ML = Data_forest_tmp_5_
          cls_met <- metric_set(brier_class)
          Data_cv <- vfold_cv(v=10, Data_ML, strata = T_N)
          Data_parameter_train = rsample::analysis(Data_cv$splits[[1]])
          Data_parameter_test = rsample::assessment(Data_cv$splits[[1]])
          Data_parameter_cv = Data_parameter_train |> 
            rsample::vfold_cv(v = 10, strata = T_N)
          Data_recipe <- Data_forest_tmp_5_ |>
            recipe(T_N ~ .) |>
            step_zv(all_predictors()) |>
            step_dummy(all_factor_predictors())
          cv_fit_pred <- function(recipe, spec, df_train, df_test, df_cv = NULL, grid = 10) {
            if(is.null(df_cv)) {
              params_grid = NULL
              wf <- 
                workflow() |> 
                workflows::add_recipe(recipe = recipe) |> 
                workflows::add_model(spec = spec)
            } else {
              cv_wf <- 
                workflow() |> 
                workflows::add_recipe(recipe = recipe) |> 
                workflows::add_model(spec = spec)
              params_grid <- 
                cv_wf |> 
                tune::tune_grid(
                  resamples = df_cv,
                  grid = grid,
                  control = tune::control_grid(save_pred = TRUE)
                )
              wf <- 
                cv_wf |> 
                tune::finalize_workflow(
                  parameters = params_grid |> tune::select_best()
                )
            }
            wf_fit <- 
              wf |> 
              parsnip::fit(data = df_train)
            pred <- 
              wf_fit |> 
              tune::augment(new_data = df_test)
            return(
              list(
                params_grid = params_grid, 
                wf_fit = wf_fit, 
                pred = pred
              )
            )
          }
          rf_spec <-
            parsnip::rand_forest() |> 
            parsnip::set_args(mtry = tune(), min_n = tune(), trees = 500) |> 
            parsnip::set_engine(
              'ranger',
              num.threads = max(1, parallel::detectCores() - 1, na.rm = TRUE)
            ) |> 
            parsnip::set_mode('classification')            
          lgb_spec <-
            parsnip::boost_tree(mode = "classification") %>%
            parsnip::set_args(
              tree_depth = tune(), min_n = tune(), mtry = tune(), trees = 500, learn_rate = 0.01, lambda_l1 = 0.9) |> 
            set_engine("lightgbm")
          
          rf_result <- 
            Data_recipe |> 
            cv_fit_pred(rf_spec, Data_parameter_train, Data_parameter_test, Data_parameter_cv)
          lgb_result <- 
            Data_recipe |> 
            cv_fit_pred(lgb_spec, Data_parameter_train, Data_parameter_test, Data_parameter_cv)
          
          rf_parameter = (rf_result$params_grid %>% show_best(metric = "brier_class"))[1,]
          lgb_parameter = (lgb_result$params_grid %>% show_best(metric = "brier_class"))[1,]
          rf_model <-
            parsnip::rand_forest() |>
            parsnip::set_args(trees = 10000, min_n = rf_parameter$min_n, mtry = rf_parameter$mtry) |>
            parsnip::set_engine(
              'ranger',
              num.threads = max(1, parallel::detectCores() - 1, na.rm = TRUE)
            ) |>
            parsnip::set_mode('classification')
          lgb_model <-
            parsnip::boost_tree(mode = "classification") %>%
            set_engine("lightgbm",
                       lambda_l1 = .9,
                       min_n = lgb_parameter$min_n,
                       tree_depth = lgb_parameter$tree_depth,
                       learn_rate = 0.01,
                       trees = 10000,
                       mtry = lgb_parameter$mtry)
          rf_wflow <- 
            workflow() %>% 
            add_model(rf_model) %>% 
            add_recipe(Data_recipe)
          lgb_wflow <- 
            workflow() %>% 
            add_model(lgb_model) %>% 
            add_recipe(Data_recipe)
          set.seed(1212)
          lgb_m2 = lgb_wflow %>% fit(Data_ML) 
          rf_m2 = rf_wflow %>% fit(Data_ML) 
          save(lgb_m2, file = "source/lgb_m2.rda")
          save(rf_m2, file = "source/rf_m2.rda")
          set.seed(1212)
          keep_pred <- control_resamples(save_pred = TRUE, save_workflow = TRUE)
          rf_res <- rf_wflow %>% fit_resamples(resamples = Data_cv, metrics = cls_met, control = keep_pred)
          rf_res_all = rf_res %>%
            pull(.predictions) %>%
            bind_rows() %>%
            dplyr::arrange(.row)
          ROC_rf <- roc(T_N ~ .pred_1, data = rf_res_all, ci = TRUE)
          gROC_rf = ggroc(ROC_rf, 
                          size = 1, #サイズ
                          legacy.axes = TRUE) + 
            geom_abline(color = "dark grey", size = 0.5) +
            theme_classic() +
            labs(
              title = 
                paste0("Random forest, AUC: ", round(ROC_rf$auc[1],3), " (95%CI:",round(ROC_rf$ci[1],3), "-", round(ROC_rf$ci[3],3), ")",
                       ", mtry/min_n=",rf_parameter$mtry,"/",rf_parameter$min_n
                      )
            )
          lgb_res <- lgb_wflow %>% fit_resamples(resamples = Data_cv, metrics = cls_met, control = keep_pred)
          lgb_res_all = lgb_res %>%
            pull(.predictions) %>%
            bind_rows() %>%
            dplyr::arrange(.row)
          ROC_lgb <- roc(T_N ~ .pred_1, data = lgb_res_all, ci = TRUE)
          gROC_lgb = ggroc(ROC_lgb, 
                           size = 1, #サイズ
                           legacy.axes = TRUE) + 
            geom_abline(color = "dark grey", size = 0.5) +
            theme_classic() +
            labs(
              title = 
                paste0("LightGBM, AUC: ", round(ROC_lgb$auc[1],3), " (95%CI:",round(ROC_lgb$ci[1],3), "-", round(ROC_lgb$ci[3],3), ")",
                       ", mtry/min_n/depth=",lgb_parameter$mtry,"/",lgb_parameter$min_n,"/",lgb_parameter$tree_depth)
            )
          g1 = collect_predictions(lgb_res) %>%
               ggplot(aes(.pred_1)) +
               theme_classic() +
               geom_histogram(col = "white", bins = 40) +
               facet_wrap(~ T_N, ncol = 1) +
               geom_rug(col = "blue", alpha = 1 / 2) + 
               labs(x = "LightGBM: Probability Estimate of germline origin")
          g2 = cal_plot_breaks(lgb_res) +
            ggtitle("LightGBM: Calibration curve")
          set.seed(1212)
          iso_val <- cal_validate_logistic(lgb_res, metrics = cls_met, 
                                                save_pred = TRUE, times = 25)
          beta_val <- cal_validate_beta(lgb_res, metrics = cls_met, save_pred = TRUE)
          g3= collect_predictions(beta_val) %>%
            filter(.type == "calibrated") %>%
            cal_plot_windowed(truth = T_N, estimate = .pred_0, step_size = 0.025) +
            ggtitle("LightGBM: Beta calibration")
          
          df_cv_pred$lgb  = (iso_val %>%
                               pull(.predictions_cal) %>%
                               bind_rows() %>%
                               dplyr::arrange(.row))$.pred_1
          collect_predictions(beta_val) %>%
            filter(.type == "calibrated") %>%
            cal_plot_windowed(truth = T_N, estimate = .pred_0, step_size = 0.025) +
            ggtitle("LightGBM: Beta calibration")
          g4 = collect_predictions(rf_res) %>%
            ggplot(aes(.pred_1)) +
            theme_classic() +
            geom_histogram(col = "white", bins = 40) +
            facet_wrap(~ T_N, ncol = 1) +
            geom_rug(col = "blue", alpha = 1 / 2) + 
            labs(x = "Random forest: Probability Estimate of germline origin")
          g5 = cal_plot_breaks(rf_res,) +
            ggtitle("Random forest: Calibration curve")

          iso_val <- cal_validate_logistic(rf_res, metrics = cls_met, 
                                                save_pred = TRUE, times = 25)
          g6= collect_predictions(beta_val) %>%
            filter(.type == "calibrated") %>%
            cal_plot_windowed(truth = T_N, estimate = .pred_0, step_size = 0.025) +
            ggtitle("Random forest: Beta calibration")
          df_cv_pred$rf  = (iso_val %>%
                               pull(.predictions_cal) %>%
                               bind_rows() %>%
                               dplyr::arrange(.row))$.pred_1
          output$figure_DCA = renderPlot({
            df_cv_pred = df_cv_pred %>%
              dplyr::mutate(
                kosugi = case_when(
                  confirmation_test == "Recommend" ~ 0.5,
                  confirmation_test == "Check_phenotype" ~ 0.05,
                  TRUE ~ 0
                )
            )
            dcurves::dca( # calculate net benefit scores on mean cross validation predictions
                data = df_cv_pred,
                formula = T_N ~ .fitted + rf + lgb + kosugi,
                thresholds = dca_thresholds,
                label = list(
                  .fitted = "10-fold cross-validated logistic regression model",
                  rf = "10-fold cross-validated random forest model",
                  lgb = "10-fold cross-validated lightGBM model",
                  kosugi = "Kosugi's criteria"
                ))$dca |> 
                # plot cross validated net benefit values
                ggplot(aes(x = threshold, y = net_benefit, color = label)) +
                stat_smooth(method = "loess", se = FALSE, formula = "y ~ x", span = 0.2, fullrange = TRUE) +
                scale_x_continuous(labels = scales::percent_format(accuracy = 1)) +
                scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
                labs(x = "Threshold probability", y = "Net Benefit", color = "") +
                coord_cartesian(xlim = c(0, 1), ylim = c(-0.01, NA)) + 
                theme_bw()
            })
          
          
          output$figure_Kosugi = renderPlot({
            df_cv_pred = df_cv_pred %>%
              dplyr::mutate(kosugi = case_when(
                confirmation_test == "Recommend" ~ 1,
                confirmation_test == "Check_phenotype" ~ 0.5,
                TRUE ~ 0
              ))
            gKosugi = df_cv_pred %>%
              ggplot(aes(kosugi)) +
              theme_classic() +
              geom_histogram(col = "white", bins = 40) +
              facet_wrap(~ T_N, ncol = 1) +
              geom_rug(col = "blue", alpha = 1 / 2) + 
              labs(x = "Kosugi's criteria: Probability Estimate of germline origin")
            ROC_Kosugi <- roc(T_N ~ kosugi, data = df_cv_pred, ci = TRUE)
            gROC_Kosugi = ggroc(ROC_Kosugi, 
                             size = 1, #サイズ
                             legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              labs(
                title = 
                  paste0("Kosugi's criteria, AUC: ", round(ROC_Kosugi$auc[1],3), " (95%CI:",round(ROC_Kosugi$ci[1],3), "-", round(ROC_Kosugi$ci[3],3), ")")
              )
            grid.arrange(gKosugi, gROC_Kosugi, ncol = 1)
          })

          output$figure_DCA_ROC = renderPlot({
            gNomogram = df_cv_pred %>%
              ggplot(aes(.fitted)) +
              theme_classic() +
              geom_histogram(col = "white", bins = 40) +
              facet_wrap(~ T_N, ncol = 1) +
              geom_rug(col = "blue", alpha = 1 / 2) + 
              labs(x = "Nomogram: Probability Estimate of germline origin")
            df_cv_pred = df_cv_pred %>%
              dplyr::mutate(kosugi = case_when(
                confirmation_test == "Recommend" ~ 0.5,
                confirmation_test == "Check_phenotype" ~ 0.05,
                TRUE ~ 0
              ))
            ROC2 <- roc(T_N ~ .fitted, data = df_cv_pred, ci = TRUE)
            gROC2 = ggroc(ROC2, 
                       size = 1, #サイズ
                       legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              labs(
                title = 
                  paste0("Nomogram, AUC: ", round(ROC2$auc[1],3), " (95%CI:",round(ROC2$ci[1],3), "-", round(ROC2$ci[3],3), ")")
              )
            ROC3 <- roc(T_N ~ .fitted + lgb + rf + kosugi, data = df_cv_pred, ci = TRUE)
            gROC3 = ggroc(ROC3, 
                          size = 1, #サイズ
                          legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              scale_color_hue(name = "Prediction methods",
                              labels = c(.fitted = "Nomogram",
                                         lgb = "Light GBM",
                                         rf  = "Random forest",
                                         kosugi = "Kosugi's criteria")) +
              labs(
                title = 
                  paste0("ROC curves for variant origin prediction")
              )
            grid.arrange(gNomogram,gROC2,gROC3, nrow = 3)
          })

          output$figure_Machine_learning = renderPlot({
            grid.arrange(g1,g2,g3,gROC_lgb,g4,g5,g6,gROC_rf, nrow = 4, ncol=2)
          })
          
          output$table_DCA = render_gt({
            df_cv_pred = df_cv_pred %>%
              dplyr::mutate(kosugi = case_when(
                confirmation_test == "Recommend" ~ 0.5,
                confirmation_test == "Check_phenotype" ~ 0.05,
                TRUE ~ 0
              ))
            (dcurves::dca( # calculate net benefit scores on mean cross validation predictions
                data = df_cv_pred,
                formula = T_N ~ .fitted + rf + lgb + kosugi,
                thresholds = dca_thresholds,
                label = list(
                  .fitted = "10-fold cross-validated logistic regression model",
                  rf = "10-fold cross-validated random forest model",
                  lgb = "10-fold cross-validated lightGBM model",
                  kosugi = "Kosugi's criteria"
                ))) %>%
                net_intervention_avoided() %>%
                as_tibble() %>%
                gt::gt() %>%
                gt::fmt_percent(columns = threshold, decimals = 0) %>%
                gt::fmt(columns = net_benefit, fns = function(x) style_sigfig(x, digits = 3)) %>%
                gt::cols_label(
                  label = "Strategy",
                  threshold = "Decision Threshold",
                  net_benefit = "Net Benefit"
                ) %>%
                gt::cols_align("left", columns = label)
            })
          
          output$table_prediction = DT::renderDataTable(df_cv_pred,
                                                     server = FALSE,
                                                     filter = 'top', 
                                                     extensions = c('Buttons'), 
                                                     options = list(pageLength = 100, 
                                                                    scrollX = TRUE,
                                                                    scrollY = "1000px",
                                                                    scrollCollapse = TRUE,
                                                                    dom="Blfrtip",
                                                                    buttons = c('csv', 'copy')))
          }
        }
      }
      incProgress(1 / 13)
    })
  })
  
  observeEvent(input$SF_PGPV_prediction, {
    withProgress(message = sample(nietzsche)[1], {
      Data_case_target = Data_case()
      incProgress(1 / 13)
      Data_forest = Data_case_target %>%
        dplyr::select(age,
                      YoungOld,
                      Gene,
                      Mismatch_Rate_Tumor,
                      gnomADg_AF_eas,
                      ToMMo_AF,
                      sex,
                      pathology_top,
                      sampling_site,
                      tumor_content,
                      smoking_history,
                      alcohol,
                      double_cancer,
                      multiple_nodule,
                      cancer_family_history,
                      Variant_Type,
                      Panel,
                      Oncogene_TSG,
                      Conversion_rate,
                      confirmation_test
        )
      Data_forest = Data_forest %>% dplyr::filter(
        Mismatch_Rate_Tumor >= 0.05 &
        Gene %in% SF_Genes
      )
      frequent_genes = sort(table(Data_forest$Gene),decreasing = T)
      frequent_genes_names = names(frequent_genes[frequent_genes>=50])
      frequent_organs = sort(table(Data_forest$pathology_top),decreasing = T)
      frequent_organs_names = names(frequent_organs[frequent_organs>=50])
      Data_forest = Data_forest %>% dplyr::mutate(
        VAF = case_when(
          Mismatch_Rate_Tumor < 0.3  ~ "5_29",
          TRUE ~ "30_"
        ),
        relative_VAF = case_when(
          fun_zero(Mismatch_Rate_Tumor,tumor_content) < 0.01 ~ "0_99",
          TRUE ~ "100_"
        ),
        Gene_type = Gene,
        Organ_type = case_when(
          pathology_top %in% frequent_organs_names ~ pathology_top,
          TRUE ~ "Rare_organs"
        ),
        Mut_in_healthy = case_when(
          gnomADg_AF_eas > 0 | ToMMo_AF > 0 ~ "Yes",
          TRUE ~ "No"
        ),
        Mut_Pattern = case_when(
          Variant_Type %in% c("DNP_G", "DNP_S", "TNP_G", "TNP_S", "ONP_G", "ONP_S", "Other") ~ "Other",
          Variant_Type %in% c("SNP_G", "SNP_S") ~ "SNP",
          Variant_Type %in% c("INS_G", "INS_S") ~ "INS",
          Variant_Type %in% c("DEL_G", "DEL_S") ~ "DEL",
          TRUE ~ "Other"
        ),
        T_N = case_when(
          Panel == "NOP_T" ~ 0,
          TRUE ~ 1
        )
      )
      
      Data_forest_tmp__ = Data_forest %>%
        dplyr::filter(Mut_Pattern != "Other" &
                        Gene_type != "Other" &
                        !is.na(tumor_content) &
                        sampling_site != "Unknown" &
                        smoking_history != "Unknown" &
                        alcohol != "Unknown" &
                        double_cancer != "Unknown" &
                        multiple_nodule != "Unknown" &
                        cancer_family_history != "Unknown"
        )
      
      Disease_tmp = unique(sort(Data_forest_tmp__$Organ_type))
      for(i in 1:length(Disease_tmp)){
        Data_forest_tmp_2_ = Data_forest_tmp__ %>% dplyr::filter(Organ_type == Disease_tmp[i])
        if(sum(Data_forest_tmp_2_$T_N == 1) < 3){
          Data_forest_tmp__ = Data_forest_tmp__ %>%
            dplyr::mutate(Organ_type = case_when(
              Organ_type == Disease_tmp[i] ~ "Rare_organs",
              TRUE ~ Organ_type
            )
            )
        }
      }
      Data_figure =  Data_forest_tmp__ %>%
        dplyr::mutate(
          relative_VAF =  fun_zero(Mismatch_Rate_Tumor,tumor_content)*100,
          T_N = as.factor(T_N)
        )
      g_basic_1 = Data_figure %>%
        ggplot(aes(x = Mismatch_Rate_Tumor, fill = T_N)) +
        geom_histogram(boundary=0, binwidth = 0.05, position="stack") +
        theme_classic()+
        labs(x = "Variant allele frequency",
             y = "Counts",
             title = "Variant allele frequency in tumor panel",
             fill = "Germline or somatic") +
        scale_fill_discrete(labels = c("0" = "Somatic", "1" ="Germline")) +
        geom_vline(xintercept=0.3, linetype = "dashed",colour = "blue") +
        scale_x_continuous(limits = c(0, 1), breaks = seq(0, 1, 0.1))
      g_basic_2 = Data_figure %>%
        ggplot(aes(x = relative_VAF, fill = T_N)) +
        geom_histogram(boundary=0, binwidth = 0.1, position="stack") +
        theme_classic()+
        labs(x = "Relative variant allele frequency",
             y = "Counts",
             title = "Variant allele frequency to tumor content ratio in tumor panel",
             fill = "Germline or somatic") +
        scale_fill_discrete(labels = c("0" = "Somatic", "1" ="Germline")) +
        geom_vline(xintercept=1, linetype = "dashed",colour = "blue") +
        scale_x_continuous(limits = c(0, 8), breaks = seq(0, 8, 1))
      output$SF_figure_GPV_basic_data = renderPlot({
        grid.arrange(g_basic_1, g_basic_2, ncol = 1, nrow = 2)
      })
      
      Data_forest_tmp_5 = Data_forest_tmp__ %>%
        dplyr::select(-Gene, -relative_VAF, -gnomADg_AF_eas, -ToMMo_AF, -Panel,-YoungOld,
                      -pathology_top, -VAF, -Oncogene_TSG, -Variant_Type, -Conversion_rate)
      Data_forest_tmp_7 = Data_forest_tmp__ %>%
        dplyr::select(-Gene, -Mismatch_Rate_Tumor, -gnomADg_AF_eas, -ToMMo_AF, -Panel,-age,
                      -pathology_top, -tumor_content, -Oncogene_TSG, -Variant_Type, -Conversion_rate)
      Organ_data = data.frame(sort(unique(Data_forest_tmp_5$Organ_type)))
      colnames(Organ_data) = c("Organ_type")
      save(file = "source/SF_Organ_data.rda", Organ_data)
      Gene_data = data.frame(sort(unique(Data_forest_tmp_5$Gene_type)))
      colnames(Gene_data) = c("Gene_type")
      save(file = "source/SF_Gene_data.rda", Gene_data)
      Data_forest_tmp_5 = data.frame( lapply(Data_forest_tmp_5, as.factor) )
      Data_forest_tmp_7 = data.frame( lapply(Data_forest_tmp_7, as.factor) )
      Data_forest_tmp_5$age = as.numeric(as.character(Data_forest_tmp_5$age))
      Data_forest_tmp_5$Mismatch_Rate_Tumor = as.numeric(as.character(Data_forest_tmp_5$Mismatch_Rate_Tumor))
      Data_forest_tmp_5$tumor_content = as.numeric(as.character(Data_forest_tmp_5$tumor_content))
      Data_forest_tmp_5$Organ_type <- relevel(Data_forest_tmp_5$Organ_type, ref=names(sort(table(Data_forest_tmp_5$Organ_type),decreasing = T))[[1]]) 
      Data_forest_tmp_7$Organ_type <- relevel(Data_forest_tmp_7$Organ_type, ref=names(sort(table(Data_forest_tmp_7$Organ_type),decreasing = T))[[1]]) 
      if(length(colnames(Data_forest_tmp_7)) > 2){
        Data_forest_tmp_5_ = Data_forest_tmp_5 %>% dplyr::select(-confirmation_test)
        Data_forest_tmp_7_ = Data_forest_tmp_7 %>% dplyr::select(-confirmation_test)
        m1 <- glm(T_N ~., data = Data_forest_tmp_7_, family = binomial(link = "logit"))
        final_mv_reg <- m1 %>%
          stats::step(direction = "backward", trace = FALSE)
      }
      output$SF_figure_Odds = render_gt({
        if(length(colnames(Data_forest_tmp_7)) > 1){
          univ_tab <- Data_forest_tmp_7 %>% 
            tbl_uvregression(                         ## 単変量解析の表を生成
              method = glm,                           ## 実行したい回帰（一般化線形モデル）を定義
              y = T_N,
              method.args = list(family = binomial),  ## 実行したい glm のタイプを定義（ここではロジスティック）
              exponentiate = TRUE                     ## 対数オッズ比ではなくオッズ比を得るために指数変換を指定
            ) |>
            add_global_p() |> # add global p-value
            add_n(location = "level") |>
            add_nevent(location = "level") |> # add number of events of the outcome
            add_q() |> # adjusts global p-values for multiple testing
            bold_p() |> # bold p-values under a given threshold (default 0.05)
            modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
            bold_labels()
          if(!is.null(final_mv_reg$xlevels)){
            mv_tab = final_mv_reg |>
              tbl_regression(
                exponentiate = TRUE
              ) |>
              add_global_p() |>
              add_q() |>
              bold_p() |>
              modify_fmt_fun(conf.low ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(conf.high ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              modify_fmt_fun(estimate ~ function(x) ifelse(Abs(x)>100 | Abs(x)<0.01, format(x, digits = 3, scientific = TRUE), ifelse(Abs(x) != 1, format(x, digits = 3), x))) |>
              bold_labels()
            tbl_merge(
              tbls = list(univ_tab, mv_tab),
              tab_spanner = c("**Univariate**", "**Multivariable**")) |>
              modify_caption("Factors predicting germline origin") |> as_gt()
          } else {
            univ_tab |>
              modify_caption("Factors predicting germline origin, no significant factor in multivariable analysis") |> as_gt()
          }
        }
      })
      
      Data_forest_tmp_8 = Data_forest_tmp_7
      if(length(colnames(Data_forest_tmp_8)) > 1){
        if(!is.null(final_mv_reg$xlevels)){
          Data_forest_tmp_treat = Data_forest_tmp_8 %>% dplyr::select(c("T_N", names(final_mv_reg$xlevels)))
          if(length(colnames(Data_forest_tmp_treat)) > 1){
            dd <- datadist(Data_forest_tmp_treat) 
            options(datadist=dd)
            formula_treat = formula(paste0("T_N ~ ",paste(colnames(Data_forest_tmp_treat)[colnames(Data_forest_tmp_treat)!="T_N"], collapse="+")))
            m2 <- lrm(formula_treat,
                      data = Data_forest_tmp_treat,x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)
            save(m2, file = "source/SF_m2.rda")
            # error in rms package
            val <- try(rms::validate(m2, B=500), silent = FALSE)
            if (class(val) == "try-error") {
              val = rms::validate(m2, B=500)
            }
            # do not delete
            cal = rms::calibrate(m2, B=500)
            options(datadist=NULL)
            log_nomogram <- nomogram(m2, fun = plogis, fun.at=c(.001,.01,.1,.5,.9,.99,.999), lp=F, funlabel="Germline origin")
          }
        }
      }
      
      output$SF_figure_nomogram = renderPlot({
        if(length(colnames(Data_forest_tmp_8)) > 1){
          if(!is.null(final_mv_reg$xlevels)){
            if(length(colnames(Data_forest_tmp_treat)) > 1){
              par(mfcol = c(2, 1))
              plot(cal, lwd=2, lty=1, 
                   cex.lab=1.2, cex.axis=1, cex.main=1.2, cex.sub=0.6, 
                   xlim=c(0, 1), ylim= c(0, 1), 
                   xlab="Nomogram-Predicted Probability of germline origin", 
                   ylab="Actual germline variants (proportion)",
                   legend=FALSE)
              #lines(cal[, c(1:3)], type ="o", lwd=1, pch=16, col=c("#00468BFF"))
              abline(0, 1, lty=3, lwd=2,  col=c("#224444")) 
              text(x=.6, y=.0, adj = c(0,0), paste0("Germline conversion rate","\n",
                                                    "Nagelkerke R2 = ", round(val[2,5], digits=3),'\n',
                                                    "500-time-bootstrapped-concordance index = ", round(((val[1,5] + 1) / 2), digits=3),"\n",
                                                    "Intercept = ",round(val[3,5], digits=3),"\n",
                                                    "Slope = ", round(val[4,5], digits=3)))
              legend(x=.8, y=.2, legend=c("Apparent", "Bias-corrected", "Ideal"), 
                     lty=c(3, 1, 2), bty="n")
              text(x=-0.0, y=.4, cex=1, adj = c(0,0),
                   paste0("Gene type\n",
                          paste(log_nomogram$Gene_type$Gene_type, collapse = "\n")))
              text(x=.12, y=.4, cex=1, adj = c(0,0),
                   paste0("Point\n",
                          paste(round(log_nomogram$Gene_type$points,digits = 0), collapse = "\n")))
              text(x=.25, y=.67, cex=1, adj = c(0,0),
                   paste0("Organ type\n",
                          paste(log_nomogram$Organ_type$Organ_type, collapse = "\n")))
              text(x=.40, y=.67, cex=1, adj = c(0,0),
                   paste0("Point\n",
                          paste(round(log_nomogram$Organ_type$points,digits = 0), collapse = "\n")))
              plot(log_nomogram)
            } else {
              gg_empty()
            }
          } else {
            gg_empty()
          }
        } else {
          gg_empty()
        }
      })
      
      if(length(colnames(Data_forest_tmp_8)) > 1){
        if(!is.null(final_mv_reg$xlevels)){
          if(length(colnames(Data_forest_tmp_treat)) > 1){
            Data_forest_tmp_treat$patientid = 1:length(Data_forest_tmp_treat$T_N)
            Data_forest_tmp_8$patientid = 1:length(Data_forest_tmp_8$T_N)
            dca_thresholds = seq(0, 1.00, 0.05)
            set.seed(1212)            
            # create a 10-fold cross validation set, 1 repeat which is the base case, change to suit your use case
            cross_validation_samples <- rsample::vfold_cv(Data_forest_tmp_treat, strata = "T_N", v = 10, repeats = 1)
            
            df_crossval_predictions <- 
              cross_validation_samples %>% 
              dplyr::mutate(
                glm_analysis = c(list(lrm(formula = formula_treat, data = rsample::analysis(splits[[1]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[2]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[3]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[4]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[5]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[6]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[7]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[8]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[9]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)),
                                 list(lrm(formula = formula_treat, data = rsample::analysis(splits[[10]]),x=TRUE,y=TRUE,penalty = 0.5, tol=10^-16)))
              )
            df_prediction_id = c(rsample::assessment(df_crossval_predictions$splits[[1]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[2]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[3]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[4]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[5]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[6]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[7]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[8]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[9]])$patientid,
                                 rsample::assessment(df_crossval_predictions$splits[[10]])$patientid
            )
            
            df_prediction_score = c(predict(df_crossval_predictions$glm_analysis[[1]], rsample::assessment(df_crossval_predictions$splits[[1]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[2]], rsample::assessment(df_crossval_predictions$splits[[2]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[3]], rsample::assessment(df_crossval_predictions$splits[[3]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[4]], rsample::assessment(df_crossval_predictions$splits[[4]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[5]], rsample::assessment(df_crossval_predictions$splits[[5]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[6]], rsample::assessment(df_crossval_predictions$splits[[6]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[7]], rsample::assessment(df_crossval_predictions$splits[[7]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[8]], rsample::assessment(df_crossval_predictions$splits[[8]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[9]], rsample::assessment(df_crossval_predictions$splits[[9]]),type = "fitted"),
                                    predict(df_crossval_predictions$glm_analysis[[10]], rsample::assessment(df_crossval_predictions$splits[[10]]),type = "fitted")
            )
            df_prediction = data.frame(df_prediction_id, df_prediction_score)
            colnames(df_prediction) = c("patientid", ".fitted")
            
            df_cv_pred <-
              Data_forest_tmp_treat %>%
              dplyr::left_join(
                df_prediction,
                by = 'patientid'
              ) %>%
              dplyr::left_join(
                Data_forest_tmp_8 %>% dplyr::select(patientid, confirmation_test),
                by = 'patientid'
              )

            
            set.seed(1212)
            Data_ML = Data_forest_tmp_5_
            cls_met <- metric_set(brier_class)
            Data_cv <- vfold_cv(v=10, Data_ML, strata = T_N)
            Data_parameter_train = rsample::analysis(Data_cv$splits[[1]])
            Data_parameter_test = rsample::assessment(Data_cv$splits[[1]])
            Data_parameter_cv = Data_parameter_train |> 
              rsample::vfold_cv(v = 10, strata = T_N)
            Data_recipe <- Data_forest_tmp_5_ |>
              recipe(T_N ~ .) |>
              step_zv(all_predictors())# |>
              #step_dummy(all_nominal_predictors())
            cv_fit_pred <- function(recipe, spec, df_train, df_test, df_cv = NULL, grid = 10) {
              if(is.null(df_cv)) {
                params_grid = NULL
                wf <- 
                  workflow() |> 
                  workflows::add_recipe(recipe = recipe) |> 
                  workflows::add_model(spec = spec)
              } else {
                cv_wf <- 
                  workflow() |> 
                  workflows::add_recipe(recipe = recipe) |> 
                  workflows::add_model(spec = spec)
                params_grid <- 
                  cv_wf |> 
                  tune::tune_grid(
                    resamples = df_cv,
                    grid = grid,
                    control = tune::control_grid(save_pred = TRUE)
                  )
                wf <- 
                  cv_wf |> 
                  tune::finalize_workflow(
                    parameters = params_grid |> tune::select_best()
                  )
              }
              wf_fit <- 
                wf |> 
                parsnip::fit(data = df_train)
              pred <- 
                wf_fit |> 
                tune::augment(new_data = df_test)
              return(
                list(
                  params_grid = params_grid, 
                  wf_fit = wf_fit, 
                  pred = pred
                )
              )
            }
            rf_spec <-
              parsnip::rand_forest() |> 
              parsnip::set_args(mtry = tune(), min_n = tune(), trees = 500) |> 
              parsnip::set_engine(
                'ranger',
                num.threads = max(1, parallel::detectCores() - 1, na.rm = TRUE)
              ) |> 
              parsnip::set_mode('classification')            
            lgb_spec <-
              parsnip::boost_tree(mode = "classification") %>%
              parsnip::set_args(
                tree_depth = tune(), min_n = tune(), mtry = tune(), trees = 500, learn_rate = 0.01, lambda_l1 = 0.9) |> 
              set_engine("lightgbm")
            
            rf_result <- 
              Data_recipe |> 
              cv_fit_pred(rf_spec, Data_parameter_train, Data_parameter_test, Data_parameter_cv)
            lgb_result <- 
              Data_recipe |> 
              cv_fit_pred(lgb_spec, Data_parameter_train, Data_parameter_test, Data_parameter_cv)

            rf_parameter = (rf_result$params_grid %>% show_best(metric = "brier_class"))[1,]
            lgb_parameter = (lgb_result$params_grid %>% show_best(metric = "brier_class"))[1,]
            rf_model <-
              parsnip::rand_forest() |>
              parsnip::set_args(trees = 10000, min_n = rf_parameter$min_n, mtry = rf_parameter$mtry) |>
              parsnip::set_engine(
                'ranger',
                num.threads = max(1, parallel::detectCores() - 1, na.rm = TRUE)
              ) |>
              parsnip::set_mode('classification')
            lgb_model <-
              parsnip::boost_tree(mode = "classification") %>%
              set_engine("lightgbm",
                         lambda_l1 = .9,
                         min_n = lgb_parameter$min_n,
                         tree_depth = lgb_parameter$tree_depth,
                         learn_rate = 0.01,
                         trees = 10000,
                         mtry = lgb_parameter$mtry)
            rf_wflow <- 
              workflow() %>% 
              add_model(rf_model) %>% 
              add_recipe(Data_recipe)
            lgb_wflow <- 
              workflow() %>% 
              add_model(lgb_model) %>% 
              add_recipe(Data_recipe)
            set.seed(1212)
            lgb_m2 = lgb_wflow %>% fit(Data_ML) 
            rf_m2 = rf_wflow %>% fit(Data_ML) 
            save(lgb_m2, file = "source/SF_lgb_m2.rda")
            save(rf_m2, file = "source/SF_rf_m2.rda")
            keep_pred <- control_resamples(save_pred = TRUE, save_workflow = TRUE)
            rf_res <- rf_wflow %>% fit_resamples(resamples = Data_cv, metrics = cls_met, control = keep_pred)
            rf_res_all = rf_res %>%
              pull(.predictions) %>%
              bind_rows() %>%
              dplyr::arrange(.row)
            ROC_rf <- roc(T_N ~ .pred_1, data = rf_res_all, ci = TRUE)
            gROC_rf = ggroc(ROC_rf, 
                            size = 1, #サイズ
                            legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              labs(
                title = 
                  paste0("Random forest, AUC: ", round(ROC_rf$auc[1],3), " (95%CI:",round(ROC_rf$ci[1],3), "-", round(ROC_rf$ci[3],3), ")",
                         ", mtry/min_n=",rf_parameter$mtry,"/",rf_parameter$min_n)
              )
            lgb_res <- lgb_wflow %>% fit_resamples(resamples = Data_cv, metrics = cls_met, control = keep_pred)
            lgb_res_all = lgb_res %>%
              pull(.predictions) %>%
              bind_rows() %>%
              dplyr::arrange(.row)
            ROC_lgb <- roc(T_N ~ .pred_1, data = lgb_res_all, ci = TRUE)
            gROC_lgb = ggroc(ROC_lgb, 
                             size = 1, #サイズ
                             legacy.axes = TRUE) + 
              geom_abline(color = "dark grey", size = 0.5) +
              theme_classic() +
              labs(
                title = 
                  paste0("LightGBM, AUC: ", round(ROC_lgb$auc[1],3), " (95%CI:",round(ROC_lgb$ci[1],3), "-", round(ROC_lgb$ci[3],3), ")",
                         ", mtry/min_n/tree_depth=",lgb_parameter$mtry,"/",lgb_parameter$min_n,"/",lgb_parameter$tree_depth
                        )
              )
            g1 = collect_predictions(lgb_res) %>%
              ggplot(aes(.pred_1)) +
              theme_classic() +
              geom_histogram(col = "white", bins = 40) +
              facet_wrap(~ T_N, ncol = 1) +
              geom_rug(col = "blue", alpha = 1 / 2) + 
              labs(x = "LightGBM: Probability Estimate of germline origin")
            g2 = lgb_res %>% cal_plot_windowed(truth = T_N, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
              ggtitle("LightGBM: Calibration curve")
            set.seed(1212)
            iso_val <- cal_validate_logistic(lgb_res, metrics = cls_met, 
                                             save_pred = TRUE, times = 25)
            beta_val <- cal_validate_beta(lgb_res, metrics = cls_met, save_pred = TRUE)
            g3= collect_predictions(beta_val) %>%
              filter(.type == "calibrated") %>%
              cal_plot_windowed(truth = T_N, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
              ggtitle("LightGBM: Beta calibration")
            
            df_cv_pred$lgb  = (iso_val %>%
                                 pull(.predictions_cal) %>%
                                 bind_rows() %>%
                                 dplyr::arrange(.row))$.pred_1
            collect_predictions(beta_val) %>%
              filter(.type == "calibrated") %>%
              cal_plot_windowed(truth = T_N, estimate = .pred_0, step_size = 0.025) +
              ggtitle("LightGBM: Beta calibration")
            g4 = collect_predictions(rf_res) %>%
              ggplot(aes(.pred_1)) +
              theme_classic() +
              geom_histogram(col = "white", bins = 40) +
              facet_wrap(~ T_N, ncol = 1) +
              geom_rug(col = "blue", alpha = 1 / 2) + 
              labs(x = "Random forest: Probability Estimate of germline origin")
            g5 = rf_res %>% cal_plot_windowed(event_level = 'second', truth = T_N, estimate = .pred_1, step_size = 0.025) +
              ggtitle("Random forest: Calibration curve")
            
            iso_val <- cal_validate_logistic(rf_res, metrics = cls_met, 
                                             save_pred = TRUE, times = 25)
            g6= collect_predictions(beta_val) %>%
              filter(.type == "calibrated") %>%
              cal_plot_windowed(truth = T_N, event_level = 'second', estimate = .pred_1, step_size = 0.025) +
              ggtitle("Random forest: Beta calibration")
            df_cv_pred$rf  = (iso_val %>%
                                pull(.predictions_cal) %>%
                                bind_rows() %>%
                                dplyr::arrange(.row))$.pred_1
            output$SF_figure_DCA = renderPlot({
              df_cv_pred = df_cv_pred %>%
                dplyr::mutate(
                  kosugi = case_when(
                    confirmation_test == "Recommend" ~ 0.5,
                    confirmation_test == "Check_phenotype" ~ 0.05,
                    TRUE ~ 0
                  )
                )
              dcurves::dca( # calculate net benefit scores on mean cross validation predictions
                data = df_cv_pred,
                formula = T_N ~ .fitted + rf + lgb + kosugi,
                thresholds = dca_thresholds,
                label = list(
                  .fitted = "10-fold cross-validated logistic regression model",
                  rf = "10-fold cross-validated random forest model",
                  lgb = "10-fold cross-validated lightGBM model",
                  kosugi = "Kosugi's criteria"
                ))$dca |> 
                # plot cross validated net benefit values
                ggplot(aes(x = threshold, y = net_benefit, color = label)) +
                stat_smooth(method = "loess", se = FALSE, formula = "y ~ x", span = 0.2, fullrange = TRUE) +
                scale_x_continuous(labels = scales::percent_format(accuracy = 1)) +
                scale_y_continuous(labels = scales::percent_format(accuracy = 1)) +
                labs(x = "Threshold probability", y = "Net Benefit", color = "") +
                coord_cartesian(xlim = c(0, 1), ylim = c(-0.01, NA)) + 
                theme_bw()
            })
            
            
            output$SF_figure_Kosugi = renderPlot({
              df_cv_pred = df_cv_pred %>%
                dplyr::mutate(kosugi = case_when(
                  confirmation_test == "Recommend" ~ 1,
                  confirmation_test == "Check_phenotype" ~ 0.5,
                  TRUE ~ 0
                ))
              gKosugi = df_cv_pred %>%
                ggplot(aes(kosugi)) +
                theme_classic() +
                geom_histogram(col = "white", bins = 40) +
                facet_wrap(~ T_N, ncol = 1) +
                geom_rug(col = "blue", alpha = 1 / 2) + 
                labs(x = "Kosugi's criteria: Probability Estimate of germline origin")
              ROC_Kosugi <- roc(T_N ~ kosugi, data = df_cv_pred, ci = TRUE)
              gROC_Kosugi = ggroc(ROC_Kosugi, 
                                  size = 1, #サイズ
                                  legacy.axes = TRUE) + 
                geom_abline(color = "dark grey", size = 0.5) +
                theme_classic() +
                labs(
                  title = 
                    paste0("Kosugi's criteria, AUC: ", round(ROC_Kosugi$auc[1],3), " (95%CI:",round(ROC_Kosugi$ci[1],3), "-", round(ROC_Kosugi$ci[3],3), ")")
                )
              grid.arrange(gKosugi, gROC_Kosugi, ncol = 1)
            })
            
            output$SF_figure_DCA_ROC = renderPlot({
              gNomogram = df_cv_pred %>%
                ggplot(aes(.fitted)) +
                theme_classic() +
                geom_histogram(col = "white", bins = 40) +
                facet_wrap(~ T_N, ncol = 1) +
                geom_rug(col = "blue", alpha = 1 / 2) + 
                labs(x = "Nomogram: Probability Estimate of germline origin")
              df_cv_pred = df_cv_pred %>%
                dplyr::mutate(kosugi = case_when(
                  confirmation_test == "Recommend" ~ 0.5,
                  confirmation_test == "Check_phenotype" ~ 0.05,
                  TRUE ~ 0
                ))
              ROC2 <- roc(T_N ~ .fitted, data = df_cv_pred, ci = TRUE)
              gROC2 = ggroc(ROC2, 
                            size = 1, #サイズ
                            legacy.axes = TRUE) + 
                geom_abline(color = "dark grey", size = 0.5) +
                theme_classic() +
                labs(
                  title = 
                    paste0("Nomogram, AUC: ", round(ROC2$auc[1],3), " (95%CI:",round(ROC2$ci[1],3), "-", round(ROC2$ci[3],3), ")")
                )
              ROC3 <- roc(T_N ~ .fitted + lgb + rf + kosugi, data = df_cv_pred, ci = TRUE)
              gROC3 = ggroc(ROC3, 
                            size = 1, #サイズ
                            legacy.axes = TRUE) + 
                geom_abline(color = "dark grey", size = 0.5) +
                theme_classic() +
                scale_color_hue(name = "Prediction methods",
                                labels = c(.fitted = "Nomogram",
                                           lgb = "Light GBM",
                                           rf  = "Random forest",
                                           kosugi = "Kosugi's criteria")) +
                labs(
                  title = 
                    paste0("ROC curves for variant origin prediction")
                )
              grid.arrange(gNomogram,gROC2,gROC3, nrow = 3)
            })
            
            output$SF_figure_Machine_learning = renderPlot({
              grid.arrange(g1,g2,g3,gROC_lgb,g4,g5,g6,gROC_rf, nrow = 4, ncol=2)
            })
            
            output$SF_table_DCA = render_gt({
              df_cv_pred = df_cv_pred %>%
                dplyr::mutate(kosugi = case_when(
                  confirmation_test == "Recommend" ~ 0.5,
                  confirmation_test == "Check_phenotype" ~ 0.05,
                  TRUE ~ 0
                ))
              (dcurves::dca( # calculate net benefit scores on mean cross validation predictions
                data = df_cv_pred,
                formula = T_N ~ .fitted + rf + lgb + kosugi,
                thresholds = dca_thresholds,
                label = list(
                  .fitted = "10-fold cross-validated logistic regression model",
                  rf = "10-fold cross-validated random forest model",
                  lgb = "10-fold cross-validated lightGBM model",
                  kosugi = "Kosugi's criteria"
                ))) %>%
                net_intervention_avoided() %>%
                as_tibble() %>%
                gt::gt() %>%
                gt::fmt_percent(columns = threshold, decimals = 0) %>%
                gt::fmt(columns = net_benefit, fns = function(x) style_sigfig(x, digits = 3)) %>%
                gt::cols_label(
                  label = "Strategy",
                  threshold = "Decision Threshold",
                  net_benefit = "Net Benefit"
                ) %>%
                gt::cols_align("left", columns = label)
            })
            
            output$SF_table_prediction = DT::renderDataTable(df_cv_pred,
                                                          server = FALSE,
                                                          filter = 'top', 
                                                          extensions = c('Buttons'), 
                                                          options = list(pageLength = 100, 
                                                                         scrollX = TRUE,
                                                                         scrollY = "1000px",
                                                                         scrollCollapse = TRUE,
                                                                         dom="Blfrtip",
                                                                         buttons = c('csv', 'copy')))
          }
        }
      }
      incProgress(1 / 13)
    })
  })  

  output$predict_method = renderUI({ 
    radioButtons(
      "predict_method", "Genes to analyze",
      choices = c("All genes", "Secondary-finding genes"),
      selected = "All genes")
  })
  tmp <- reactiveValues()
  observeEvent(input$predict_nomogram_setting, {
    withProgress(message = sample(nietzsche)[1], {
      incProgress(1 / 13)
      if(input$predict_method == "All genes"){
        load("source/m2.rda")
        load("source/lgb_m2.rda")
        load("source/rf_m2.rda")
      } else {
        load("source/SF_m2.rda")
        load("source/SF_lgb_m2.rda")
        load("source/SF_rf_m2.rda")
      }
      tmp$m2 = m2
      tmp$lgb_m2 = lgb_m2
      tmp$rf_m2 = rf_m2
      if(input$predict_method == "All genes"){
        load("source/Organ_data.rda")
        load("source/Gene_data.rda")
      } else {
        load("source/SF_Organ_data.rda")
        load("source/SF_Gene_data.rda")
      }
      output$input_age = renderUI({ 
        numericInput("predict_age", "Age",
                     value = 60,
                     min = 1,
                     max = 120,
                     step = 1)
      })
      output$input_sex = renderUI({ 
        radioButtons(
          "predict_sex", "Sex",
          choices = c("Man", "Woman"),
          selected = "Man")
      })
      output$input_sampling_site = renderUI({ 
        radioButtons(
          "predict_sampling_site", "Sampling site",
          choices = c("Primary lesion", "Metastatic lesion"),
          selected = "Primary lesion")
      })
      output$input_smoking_history = renderUI({ 
        radioButtons(
          "predict_smoking_history", "Smoking history",
          choices = c("Yes", "None"),
          selected = "None")
      })
      output$input_alcohol = renderUI({ 
        radioButtons(
          "predict_alcohol", "Alcohol",
          choices = c("Yes", "None"),
          selected = "None")
      })
      output$input_cancer_family_history = renderUI({ 
        radioButtons(
          "predict_cancer_family_history", "Cancer family history",
          choices = c("Yes", "None"),
          selected = "None")
      })
      output$input_Mut_Pattern = renderUI({ 
        radioButtons(
          "predict_Mut_Pattern", "Mutation pattern",
          choices = c("SNP", "INS", "DEL", "Other"),
          selected = "SNP")
      })
      output$input_organ = renderUI({
          pickerInput("predict_organ", "Organ",
                      choices = c("", Organ_data$Organ_type),
                      selected = "", multiple = FALSE)
      })
      output$input_double_cancer = renderUI({ 
        radioButtons(
          "predict_double_cancer", "Double cancer",
          choices = c("Yes", "None"),
          selected = "None")
      })
      output$input_multiple_nodule = renderUI({ 
        radioButtons(
          "predict_multiple_nodule", "Multiple nodule",
          choices = c("Yes", "None"),
          selected = "None")
      })
      output$input_gene = renderUI({ 
        pickerInput("predict_gene", "Gene",
                    choices = c("", Gene_data$Gene_type), 
                    selected = "", multiple = FALSE)
      })
      # output$input_conversion_rate = renderUI({ 
      #   pickerInput("predict_conversion_rate", "Known conversion rate",
      #               choices = c("High", "Middle", "Low", "Unknown"), 
      #               selected = "Unknown", multiple = FALSE)
      # })
      output$input_VAF = renderUI({ 
        numericInput("predict_VAF", "Variant allele frequency (%)",
                     value = 50,
                     min = 1,
                     max = 100,
                     step = 1)
      })
      output$input_tumor_content = renderUI({ 
        numericInput("predict_tumor_content", "Tumor content (%)",
                     value = 50,
                     min = 1,
                     max = 100,
                     step = 1)
      })
      output$input_MAF = renderUI({ 
        radioButtons(
          "predic_MAF", "Mutation in healthy population",
          choices = c("Yes", "No"),
          selected = "No")
      })
      output$conversion_rate_table <- DT::renderDataTable(
        conversion_rate_table_data,
        options = list(lengthMenu = c(10, 20), pageLength = 10)
      )
    })
  })
  observeEvent(input$start_prediction, {
    withProgress(message = sample(nietzsche)[1], {
      incProgress(1 / 13)
      predict_age = ifelse(input$predict_age <= input$mid_age, "Younger", "Older")
      predict_VAF = ifelse(input$predict_VAF < 30, "5_29", "30_")
      predict_rVAF = ifelse(fun_zero(input$predict_VAF,
                                     input$predict_tumor_content) < 1, "0_99", "100_")
      if(!is.null(input$predict_organ)){
        input_data = data.frame(
          YoungOld = predict_age,
          double_cancer = input$predict_double_cancer,
          multiple_nodule = input$predict_multiple_nodule,
          Organ_type = input$predict_organ,
          # Conversion_rate = input$predict_conversion_rate,
          VAF = predict_VAF,
          relative_VAF = predict_rVAF,
          Gene_type = input$predict_gene,
          Mut_in_healthy = input$predic_MAF
        )
      } else {
        input_data = data.frame(
          YoungOld = predict_age,
          double_cancer = input$predict_double_cancer,
          multiple_nodule = input$predict_multiple_nodule,
          VAF = predict_VAF,
          relative_VAF = predict_rVAF,
          Gene_type = input$predict_gene,
          Mut_in_healthy = input$predic_MAF
        )
      }
      input_data_ML = data.frame(
        age = input$predict_age,
        sex = input$predict_sex,
        sampling_site = input$predict_sampling_site,
        smoking_history = input$predict_smoking_history,
        alcohol = input$predict_alcohol,
        cancer_family_history = input$predict_cancer_family_history,
        Mut_Pattern = input$predict_Mut_Pattern,
        double_cancer = input$predict_double_cancer,
        multiple_nodule = input$predict_multiple_nodule,
        Organ_type = input$predict_organ,
        # Conversion_rate = input$predict_conversion_rate,
        Mismatch_Rate_Tumor = input$predict_VAF / 100,
        tumor_content = input$predict_tumor_content,
        Gene_type = input$predict_gene,
        Mut_in_healthy = input$predic_MAF
      )
      predicted_score = predict(tmp$m2, input_data, type = "fitted")
      predicted_score_lgb = predict(tmp$lgb_m2, input_data_ML, type = "prob")
      predicted_score_rf = predict(tmp$rf_m2, input_data_ML, type = "prob")
      output$prediction_nomogram = renderText({
        paste0("Predicted germline origin rate\n",
               "Nomogram: ", round(predicted_score, digits=2)*100, "%\n",
               "LightGBM: ", round(predicted_score_lgb[2], digits=2)*100, "%\n",
               "Random forest: ", round(predicted_score_rf[2], digits=2)*100, "%"
        )
      })
      incProgress(1 / 13)
    })
  })
}
# Run the application 
shinyApp(ui = ui, server = server)
