library(shiny)
library(shinyWidgets)
library(shinydashboard)
library(readr)
library(dplyr)
library(stringr)
library(DT)
library(rms)
library(tidymodels)
library(qs2)


tidymodels_prefer()
options(pillar.advice = FALSE, pillar.min_title_chars = Inf)

nietzsche = read.csv(header = TRUE,
                     file("source/nietzsche.csv",
                          encoding='UTF-8-BOM'))$text
SF_Genes = read.csv("source/SF_Genes.tsv",sep = "\t")$Gene
on_tumor_data = read.csv("source/on_tumor.tsv", sep="\t")
conversion_rate_table_data = read.csv("source/conversion_rate_table_data.tsv", sep="\t")
ESMO_data = read.csv("source/ESMO.tsv", sep="\t")
cancer_gene_list = read.csv(header = TRUE,sep = "\t",
                     file("source/cancerGeneList_oncoKB.txt",
                          encoding='UTF-8-BOM'))
histology_list = read.csv(header = FALSE,sep = "\t",
                            file("source/info.txt"))
histology_list = str_split(histology_list[,1], "_in_", simplify = T)[,2]
histology_name = str_split(histology_list, "_total_", simplify = T)[,1]
histology_number = str_split(histology_list, "_total_", simplify = T)[,2]
histology_number = str_split(histology_number, "_patients", simplify = T)[,1]
histology_number = as.integer(histology_number)
names(histology_number) = histology_name
histology_number["BRAIN"] = histology_number["BRAIN"] + histology_number["WHO_BRAIN"]
histology_number = histology_number[names(histology_number) != "WHO_BRAIN"]
Young_genes = c("APC", "PTEN", "RB1", "TP53", "CDKN2A", "SMARCA4")
MA_genes = c("BRCA1","BRCA2","MLH1","MSH2","MSH6","PALB2","RET")
HA_genes = c("APC", "BMPR1A", "BRIP1", "MAX", "MEN1", "MUTYH", "NF2", "PMS2", "PTEN", "RAD51C", "RAD51D", "RB1", "SDHAF2", "SDHB", "SDHC", "SDHD", "SMAD4", "STK11", "TMEM127", "TP53", "TSC1", "TSC2", "VHL", "WT1")
SA_genes = c("ATM", "BAP1", "BARD1", "CDC73", "CDH1", "CDK4", "CDKN2A", "CHEK2", "DICER1", "FH", "FLCN", "HRAS", "KIT", "MET", "NF1", "NRAS", "POLD1", "POLE", "PTCH1", "SDHA", "SMAD3", "SMARCA4", "SMARCB1", "SUFU", "TERT")

Penal = 1
Toler = 10^-10
SIZE_FONT = 14
# Specify the application port
# options(shiny.host = "0.0.0.0")
# options(shiny.port = 3838)

options(shiny.maxRequestSize=16*1024^3)


tmp <- reactiveValues()
load("source/SF_m2.rda")
load("source/SF_Organ_data.rda")
load("source/SF_Gene_data.rda")
tmp$m2 = tmp_m2
tmp$lgb_m2 = qs2::qs_read(file = "source/SF_lgb_m2.qs")
tmp$rf_m2 = qs2::qs_read(file = "source/SF_rf_m2.qs")


fun_zero <- function(a, b){
  if(length(a) != length(b)){
    if(length(a) / length(b) == as.integer(length(a) / length(b))){
      b = rep(b,length(a) / length(b))
    }
  }
  return(ifelse(b == 0, 0, a / b))
}

# Define UI for application that draws a histogram
ui <- dashboardPage(skin = "black",
  dashboardHeader(tags$li(class = "dropdown",
                          tags$table(style="80%;align:center;border-collapse:seperate;border-spacing:20px;"),
                          tags$style(".main-header {max-height: 30px}"),
                          tags$style(".main-header .logo {height: 30px;}"),
                          tags$style(".sidebar-toggle {height: 30px; padding-top: 1px !important;}"),
                          tags$style(".navbar {min-height:30px !important}")),
                  title = HTML(
                    "<div style = 'background-color:FFFFFF; vertical-align:top'>
       <a href='https://github.com/MANO-B/U3-Nomogram'><img src = 'source/MANO.png', align = 'left', height = '30px'></a> 
       </div><h6>U3-Nomogram version 3.0.0</h6>")
  ),
  dashboardSidebar(
    tags$style(".sidebar {height: calc(100vh - 30px); overflow-y: scroll; scrollbar-width: none;.left-side}, .main-sidebar {padding-top: 30px}"),
    sidebarMenu(style = "white-space: normal;",
      h3("Prediction"),
      menuItem("Analyze your data", tabName = "Input_data", icon = icon("th")),
      hr(),
      h3("Instruction"),
      menuItem("About U3-Nomogram", tabName = "Instruction", icon = icon("th")),
      hr()
    )
  ),
  ## Body content
  dashboardBody(style='overflow-x: scroll;overflow-y: scroll;',
                tags$head(tags$style(HTML('
      .main-header .sidebar-toggle:before {
        content: "\\e068";}'))),
    tabItems(
      tabItem(tabName = "Input_data",
              htmlOutput("predict_method"),
              br(),
              hr(),
              fluidRow(
                column(3,strong("Clinical information"),
                       hr(),
                       htmlOutput("input_age"),
                       htmlOutput("input_sex"),
                       htmlOutput("input_sampling_site"),
                       htmlOutput("input_smoking_history"),
                       htmlOutput("input_alcohol"),
                       htmlOutput("input_cancer_family_history"),
                       htmlOutput("input_organ"),
                       htmlOutput("input_double_cancer"),
                       htmlOutput("input_multiple_nodule"),
                       br(),
                       hr()
                ),
                column(3,strong("Mutation information"),
                       hr(),
                       htmlOutput("input_gene"),
                       htmlOutput("input_on_tumor"),
                       htmlOutput("input_Mut_Pattern"),
                       htmlOutput("input_VAF"),
                       htmlOutput("input_tumor_content"),
                       p("Check allele/genotype frequency in healthy population."),
                       a(href="https://jmorp.megabank.tohoku.ac.jp/",p("https://jmorp.megabank.tohoku.ac.jp/")),
                       htmlOutput("input_MAF")#,
                       #htmlOutput("input_conversion_rate")
                ),
                column(6,
                       shinydashboard::box(
                         title = "Known conversion rate by Kosugi",
                         DT::DTOutput("conversion_rate_table"),
                         width = NULL
                       ),
                       p("Tumor type A: Breast Cancer, CNS Cancer, Glioma, Nerve Sheath Tumor, Peripheral Nervous System, PHEO-PGL"),
                       p("Tumor type B: Adrenocortical Carcinoma, Bone Cancer, Breast Cancer, CNS Cancer, Colorectal Cancer, Embryonal Tumor, Gestational Trophoblastic Disease, Glioma, Soft Tissue Sarcoma, Wilms Tumor"),
                       shinydashboard::box(
                         title = "On-tumor genes by ESMO",
                         DT::DTOutput("on_tumor_table"),
                         width = NULL
                       ),
                       p("https://doi.org/10.1016/j.annonc.2022.12.003")
                ),
              ),
              br(),
              hr(),
              br(),
              actionButton("start_prediction", "Start prediction"),
              hr(),
              verbatimTextOutput("prediction_nomogram"),
              br(),
              p("This algorithm has not been certified for actual medical use. The decision to perform a confirmatory test is the responsibility of the attending physician."),
              br(),
              hr(),
              htmlOutput("select_age_threshold_no"),
              htmlOutput("select_mid_age"),
              htmlOutput("select_mid_age_2"),
              htmlOutput("select_mid_age_3"),
              htmlOutput("select_VAF_threshold_no"),
              htmlOutput("select_threshold_VAF"),
              htmlOutput("select_threshold_VAF_2"),
              htmlOutput("select_rVAF_threshold_no"),
              htmlOutput("select_threshold_rVAF"),
              htmlOutput("select_threshold_rVAF_2"),
              htmlOutput("select_TAR_threshold_no"),
              htmlOutput("select_threshold_TAR"),
              htmlOutput("select_threshold_TAR_2"),
              htmlOutput("select_threshold_MAF")
              
      ),
      tabItem("Instruction",
              includeMarkdown("www/README.md")
      )
    )
  )
)

  
# Define server logic required to draw a histogram
server <- function(input, output, session) {
  output$select_age_threshold_no = renderUI({ 
    radioButtons(
      "age_threshold_no", "Thresholds for age",
      choices = c("1", "2", "3"),
      selected = "2")
  })
  output$select_mid_age = renderUI({
    sliderInput(inputId = "mid_age", label = "Threshold age 1",
                value = 29,
                min = 0,
                max = 120,
                step = 1)
  })
  output$select_mid_age_2 = renderUI({
    sliderInput(inputId = "mid_age_2", label = "Threshold age 2 (if any)",
                value = 49,
                min = 0,
                max = 120,
                step = 1)
  })
  output$select_mid_age_3 = renderUI({
    sliderInput(inputId = "mid_age_3", label = "Threshold age 3 (if any)",
                value = 69,
                min = 0,
                max = 120,
                step = 1)
  })
  output$select_VAF_threshold_no = renderUI({ 
    radioButtons(
      "VAF_threshold_no", "Thresholds for VAF",
      choices = c("1", "2"),
      selected = "2")
  })
  output$select_rVAF_threshold_no = renderUI({ 
    radioButtons(
      "rVAF_threshold_no", "Thresholds for relative VAF",
      choices = c("1", "2"),
      selected = "2")
  })
  output$select_TAR_threshold_no = renderUI({ 
    radioButtons(
      "TAR_threshold_no", "Thresholds for TAR",
      choices = c("1", "2"),
      selected = "2")
  })
  output$select_threshold_VAF = renderUI({ 
    numericInput(inputId = "threshold_VAF", label = "VAF thresholds 1 (%)",
                 value = 30,
                 min = 0,
                 max = 100,
                 step = 1)
  })
  output$select_threshold_VAF_2 = renderUI({ 
    numericInput(inputId = "threshold_VAF_2", label = "VAF thresholds 2 (%)",
                 value = 70,
                 min = 0,
                 max = 100,
                 step = 1)
  })
  output$select_threshold_rVAF = renderUI({ 
    numericInput(inputId = "threshold_rVAF", label = "Relative VAF threshold 1",
                 value = 0.6,
                 min = 0,
                 max = 5,
                 step = 0.1)
  })
  output$select_threshold_rVAF_2 = renderUI({ 
    numericInput(inputId = "threshold_rVAF_2", label = "Relative VAF threshold 2",
                 value = 1.5,
                 min = 0,
                 max = 5,
                 step = 0.1)
  })
  output$select_threshold_TAR = renderUI({ 
    numericInput(inputId = "threshold_TAR", label = "Tumor allele ratio threshold 1",
                 value = 0,
                 min = -10,
                 max = 5,
                 step = 0.1)
  })
  output$select_threshold_TAR_2 = renderUI({ 
    numericInput(inputId = "threshold_TAR_2", label = "Tumor allele ratio threshold 2",
                 value = 0.8,
                 min = -10,
                 max = 5,
                 step = 0.1)
  })
  output$select_threshold_MAF = renderUI({ 
    numericInput(inputId = "threshold_MAF", label = "Threshold for minor allele frequency, SNV or not",
                 value = 0.001,
                 min = 0,
                 max = 0.1,
                 step = 0.0001)
  })
  
  output$input_age = renderUI({ 
    numericInput("predict_age", "Age",
                 value = 60,
                 min = 1,
                 max = 120,
                 step = 1)
  })
  output$input_sex = renderUI({ 
    radioButtons(
      "predict_sex", "Sex",
      choices = c("Man", "Woman"),
      selected = "Man")
  })
  output$input_sampling_site = renderUI({ 
    radioButtons(
      "predict_sampling_site", "Sampling site",
      choices = c("Primary lesion", "Metastatic lesion"),
      selected = "Primary lesion")
  })
  output$input_smoking_history = renderUI({ 
    radioButtons(
      "predict_smoking_history", "Smoking history",
      choices = c("Yes", "None"),
      selected = "None")
  })
  output$input_alcohol = renderUI({ 
    radioButtons(
      "predict_alcohol", "Alcohol",
      choices = c("Yes", "None"),
      selected = "None")
  })
  output$input_cancer_family_history = renderUI({ 
    radioButtons(
      "predict_cancer_family_history", "Cancer family history",
      choices = c("Yes", "None"),
      selected = "None")
  })
  output$input_Mut_Pattern = renderUI({ 
    radioButtons(
      "predict_Mut_Pattern", "Mutation pattern",
      choices = c("SNV", "INS", "DEL"),# "Other"),
      selected = "SNV")
  })
  output$input_organ = renderUI({
      pickerInput("predict_organ", "Organ",
                  choices = c(Organ_data$Organ_type),
                  selected = Organ_data$Organ_type[1], multiple = FALSE)
  })
  output$input_double_cancer = renderUI({ 
    radioButtons(
      "predict_double_cancer", "Double cancer",
      choices = c("Yes", "None"),
      selected = "None")
  })
  output$input_multiple_nodule = renderUI({ 
    radioButtons(
      "predict_multiple_nodule", "Multiple nodule",
      choices = c("Yes", "None"),
      selected = "None")
  })
  output$input_gene = renderUI({ 
    pickerInput("predict_gene", "Gene",
                choices = c(Gene_data$Gene_type), 
                selected = Gene_data$Gene_type[1], multiple = FALSE)
  })
  output$input_on_tumor = renderUI({ 
    radioButtons(
      "predict_on_tumor", "On-tumor gene or not",
      choices = c("Yes", "No"),
      selected = "No")
  })
  output$input_VAF = renderUI({ 
    numericInput("predict_VAF", "Variant allele frequency (%)",
                 value = 50,
                 min = 1,
                 max = 100,
                 step = 1)
  })
  output$input_tumor_content = renderUI({ 
    numericInput("predict_tumor_content", "Tumor content (%)",
                 value = 50,
                 min = 1,
                 max = 100,
                 step = 1)
  })
  output$input_MAF = renderUI({ 
    radioButtons(
      "predic_MAF", "Mutation in healthy population",
      choices = c("Yes", "No"),
      selected = "No")
  })
  output$conversion_rate_table <- DT::renderDataTable(
    conversion_rate_table_data,
    options = list(lengthMenu = c(10, 20), pageLength = 10)
  )
  output$on_tumor_table <- DT::renderDataTable(
    on_tumor_data,
    options = list(lengthMenu = c(10, 20), pageLength = 10)
  )
  observeEvent(input$start_prediction, {
    withProgress(message = sample(nietzsche)[1], {
      incProgress(1 / 13)
      predict_relative_VAF = fun_zero(input$predict_VAF, input$predict_tumor_content)
      if(input$age_threshold_no == "1"){
        predict_age = ifelse(input$predict_age <= input$mid_age, paste0("~", input$mid_age), paste0(input$mid_age + 1, "~"))
      } else if(input$age_threshold_no == "2"){
          predict_age = ifelse(input$predict_age <= input$mid_age, paste0("~", input$mid_age),
                        ifelse(input$predict_age <= input$mid_age_2, paste0(input$mid_age+1, "~", input$mid_age_2),
                               paste0(input$mid_age_2 + 1, "~")))
      } else if(input$age_threshold_no == "3"){
          predict_age = ifelse(input$predict_age <= input$mid_age, paste0("~", input$mid_age),
                               ifelse(input$predict_age <= input$mid_age_2, paste0(input$mid_age+1, "~", input$mid_age_2),
                               ifelse(input$predict_age <= input$mid_age_3, paste0(input$mid_age_2+1, "~", input$mid_age_3),
                                      paste0(input$mid_age_3 + 1, "~"))))
      }
      if(input$VAF_threshold_no == "1"){
        predict_VAF = ifelse(input$predict_VAF < input$threshold_VAF / 100, paste0("<",as.character(input$threshold_VAF)),
                             paste0(as.character(input$threshold_VAF), "~"))
      } else if(input$VAF_threshold_no == "2"){
        predict_VAF = ifelse(input$predict_VAF < input$threshold_VAF / 100, paste0("<",as.character(input$threshold_VAF)),
                             ifelse(input$predict_VAF <= input$threshold_VAF_2 / 100, paste0(as.character(input$threshold_VAF), "~", as.character(input$threshold_VAF_2)),
                                    paste0(as.character(input$threshold_VAF_2), "<")))
      }
      if(input$rVAF_threshold_no == "1"){
        predict_rVAF = ifelse(predict_relative_VAF < input$threshold_rVAF / 100, paste0("<",as.character(input$threshold_rVAF1)),
                              paste0(as.character(input$threshold_rVAF), "~"))
      } else if(input$rVAF_threshold_no == "2"){
        predict_rVAF = ifelse(predict_relative_VAF < input$threshold_rVAF / 100, paste0("<",as.character(input$threshold_rVAF1)),
                             ifelse(predict_relative_VAF <= input$threshold_rVAF_2 / 100, paste0(as.character(input$threshold_rVAF), "~", as.character(input$threshold_rVAF_2)),
                                    paste0(as.character(input$threshold_rVAF_2), "<")))
      }
      if(input$TAR_threshold_no == "1"){
        predict_TAR = ifelse(fun_zero(input$predict_VAF - 50 + 0.5 * input$predict_tumor_content, input$predict_tumor_content) < input$threshold_TAR, paste0("<",as.character(input$threshold_TAR)),
                             paste0(as.character(input$threshold_TAR), "~"))
      } else if(input$TAR_threshold_no == "2"){
        predict_TAR = ifelse(fun_zero(input$predict_VAF - 50 + 0.5 * input$predict_tumor_content, input$predict_tumor_content) < input$threshold_TAR, paste0("<",as.character(input$threshold_TAR)),
                              ifelse(fun_zero(input$predict_VAF - 50 + 0.5 * input$predict_tumor_content, input$predict_tumor_content) <= input$threshold_TAR_2, paste0(as.character(input$threshold_TAR), "~", as.character(input$threshold_TAR_2)),
                                     paste0(as.character(input$threshold_TAR_2), "<")))
      }
      Young_gene_mut = ifelse(
        input$predict_age <= 29 & input$predict_gene %in% Young_genes, "Yes", "No")
      
      input_data = data.frame(
        YoungOld = predict_age,
        sex = input$predict_sex,
        smoking_history = input$predict_smoking_history,
        alcohol = input$predict_alcohol,
        multiple_nodule = input$predict_multiple_nodule,
        Mut_Pattern = input$predict_Mut_Pattern,
        double_cancer = input$predict_double_cancer,
        multiple_nodule = input$predict_multiple_nodule,
        cancer_family_history = input$predict_cancer_family_history,
        Organ_type = input$predict_organ,
        VAF = predict_VAF,
        TAR = predict_TAR,
        rVAF = predict_rVAF,
        on_tumor = input$predict_on_tumor,
        Gene_type = input$predict_gene,
        Young_gene_mut = Young_gene_mut,
        Mut_in_healthy = input$predic_MAF
      )
      input_data_ML = data.frame(
        age = input$predict_age,
        sex = input$predict_sex,
        sampling_site = input$predict_sampling_site,
        smoking_history = input$predict_smoking_history,
        alcohol = input$predict_alcohol,
        cancer_family_history = input$predict_cancer_family_history,
        Mut_Pattern = input$predict_Mut_Pattern,
        double_cancer = input$predict_double_cancer,
        multiple_nodule = input$predict_multiple_nodule,
        Organ_type = input$predict_organ,
        Mismatch_Rate_Tumor = input$predict_VAF / 100,
        relative_VAF = predict_relative_VAF,
        on_tumor = input$predict_on_tumor,
        tumor_content = input$predict_tumor_content,
        Tar = fun_zero(input$predict_VAF - 50 + 0.5 * input$predict_tumor_content, input$predict_tumor_content),
        Gene_type = input$predict_gene,
        Young_gene_mut = Young_gene_mut,
        Mut_in_healthy = input$predic_MAF
      )
      predicted_score = predict(tmp$m2, input_data, se.fit=TRUE)
      predicted_score_lgb = predict(tmp$lgb_m2, input_data_ML, type = "prob")
      predicted_score_rf = predict(tmp$rf_m2, input_data_ML, type = "prob")
      predicted_score_rf_CI = predict(tmp$rf_m2, input_data_ML, type = "conf_int")
      output$prediction_nomogram = renderText({
        paste0("Predicted germline origin rate\n",
               "Nomogram: ", round(exp(predicted_score[[1]][[1]])/(1+exp(predicted_score[[1]][[1]])), digits=2)*100,
               "% (95%CI: ",
               round(exp(predicted_score[[1]][[1]] - 1.96 * predict(tmp$m2, input_data, se.fit=TRUE)[[2]][[1]])/(1+exp(predicted_score[[1]][[1]] - 1.96 * predict(tmp$m2, input_data, se.fit=TRUE)[[2]][[1]])), digits=2)*100, "-",
               round(exp(predicted_score[[1]][[1]] + 1.96 * predict(tmp$m2, input_data, se.fit=TRUE)[[2]][[1]])/(1+exp(predicted_score[[1]][[1]] + 1.96 * predict(tmp$m2, input_data, se.fit=TRUE)[[2]][[1]])), digits=2)*100,")\n",
               "LightGBM: ", round(predicted_score_lgb[2], digits=2)*100, "%\n",
               "Random forest: ", round(predicted_score_rf[2], digits=2)*100, "% (95%CI: ",
               round(predicted_score_rf_CI[[3]], digits=2)*100, "-",
               round(predicted_score_rf_CI[[4]], digits=2)*100,")\n"
        )
      })
      incProgress(1 / 13)
    })
  })
}
# Run the application 
shinyApp(ui = ui, server = server)
